# VLARIO Huisaansluitfiches — Complete Automatisatie
## Colas Belgium | Puurs & Zwijndrecht

---

## WAT ZIT ER IN DIT PAKKET?

| Bestand | Wat | Voor wie |
|---|---|---|
| `google_form_generator.gs` | Google Apps Script dat automatisch het werfformulier aanmaakt | Jolien (eenmalig) |
| `vlario_filler.py` | Python script: Google Sheet → VLARIO .xlsm template | Jolien (per fase) |
| `voorbeeld_werfdata.csv` | Voorbeelddata (14 rijen, Burchtsestraat fase 2) | Referentie |
| `voorbeeld_gps_topcon.csv` | Voorbeeld GPS export (7 punten) | Referentie |
| `vlario_output_zwijndrecht_fase2.xlsm` | Resultaat: ingevuld VLARIO template met testdata | Bewijs dat het werkt |

---

## STAP 1: GOOGLE FORM AANMAKEN (eenmalig, 10 minuten)

1. Ga naar **https://script.google.com**
2. Klik **Nieuw project**
3. Verwijder de standaardcode en plak de inhoud van `google_form_generator.gs`
4. Klik **▶ Uitvoeren** → kies functie `maakVLARIOForm`
5. Geef toestemming wanneer Google dit vraagt
6. Ga naar **Uitvoer** (View → Logs) om de URL van je formulier te zien

**Resultaat:** Een volledig VLARIO-conform Google Form met:
- Werf/fase selectie (Puurs 3 fases + Zwijndrecht 7 fases)
- Alle adresgegevens + equipmentnummer
- DWA/RWA/GEM/kolk selectie
- Diameter + materiaal dropdowns
- Putnummers + afstanden
- Ligging, diepte, type aansluiting, hoek
- Alle fittingen (mof, buis, bocht, Y-stuk, krimpmof, koppelstuk, reductie, stop)
- HA-putje details
- Situatieschets afstanden
- Foto-referenties
- Opmerkingen veld

**Plus:** Automatisch gekoppelde Google Sheet met alle responses.

### QR-code voor Olivier & Junior
1. Kopieer de formulier-URL
2. Ga naar https://www.qr-code-generator.com
3. Plak de URL → genereer QR-code
4. Print op A4 en hang op in de werfkeet

---

## STAP 2: DASHBOARD TOEVOEGEN (optioneel, 5 minuten)

1. Open de gekoppelde Google Sheet
2. Ga naar **Extensions → Apps Script**
3. Plak de `maakDashboard()` functie uit het `.gs` bestand
4. Voer `maakDashboard` uit
5. **Let op:** Pas de kolomreferenties aan als de kolommen in je Sheet anders staan

---

## STAP 3: PYTHON SCRIPT INSTALLEREN (eenmalig, 5 minuten)

### Vereisten
- Python 3.8+ (download: https://www.python.org/downloads/)
- openpyxl library

### Installatie
```bash
pip install openpyxl
```

### Gebruik
```bash
# Basis: werfdata + template → output
python vlario_filler.py \
  --werfdata werfdata_export.xlsx \
  --template VLARIO_template.xlsm \
  --output output_fase2.xlsm

# Met GPS data erbij
python vlario_filler.py \
  --werfdata werfdata_export.xlsx \
  --gps topcon_export.csv \
  --template VLARIO_template.xlsm \
  --output output_fase2.xlsm

# Gefilterd op werf en fase
python vlario_filler.py \
  --werfdata werfdata_export.xlsx \
  --gps topcon_export.csv \
  --template VLARIO_template.xlsm \
  --output output_zwijndrecht_f1.xlsm \
  --werf Zwijndrecht \
  --fase Burchtsestraat

# Met custom projectinfo
python vlario_filler.py \
  --werfdata werfdata_export.xlsx \
  --template VLARIO_template.xlsm \
  --output output.xlsm \
  --project-info projectinfo.json
```

### Werfdata exporteren uit Google Sheets
1. Open de gekoppelde Google Sheet
2. **Bestand → Downloaden → Microsoft Excel (.xlsx)**
3. Sla op als `werfdata_export.xlsx`
4. Draai het script

### GPS data van Topcon
1. Exporteer punten vanuit Topcon FC-6000 als CSV
2. Zorg dat kolommen bevatten: PuntID (= equipmentnr), X, Y, Z
3. Het script herkent automatisch de kolommen

---

## STAP 4: DAGELIJKSE WORKFLOW

### Op de werf (Olivier / Junior)
1. Open Google Form via QR-code op smartphone
2. Per aansluiting: vul alle velden in (3-5 min)
3. Bij gescheiden stelsel: **2× invullen** (1× DWA + 1× RWA)
4. Kolken: 1× invullen per kolk
5. Vergeet de foto's niet (apart uploaden naar gedeelde Drive-map)

### Op kantoor (Jolien)
1. Check Google Sheet op nieuwe inzendingen
2. Controleer: ontbrekende velden? Rare waarden? (gele rijen = waarschuwing)
3. Per fase/vorderingsstaat: download Sheet als .xlsx
4. Draai Python script → krijg ingevuld VLARIO template
5. Open in Excel → macro draaien → fiches aanmaken → foto's invoegen → PDF

---

## PROJECTINFO CONFIGUREREN

Pas de defaults aan in `vlario_filler.py` onder `PROJECT_DEFAULTS`, of maak een JSON bestand:

```json
{
  "rioolbeheerder": "Aquafin",
  "projectnr_rb": "23.456",
  "projectnaam": "Gescheiden riolering Burchtsestraat",
  "gemeente": "Zwijndrecht",
  "gemeentecode": "ZWI",
  "bouwheer": "Gemeente Zwijndrecht",
  "aannemer": "Colas Belgium",
  "projectnr_an": "C-2026-001",
  "werfleider": "Junior"
}
```

---

## VALIDATIE

Het script controleert automatisch:

| Type | Wat | Actie |
|---|---|---|
| ❌ Fout | Geen straatnaam | Moet opgelost worden |
| ❌ Fout | Geen equipmentnummer | Moet opgelost worden |
| ❌ Fout | Geen aard water | Moet opgelost worden |
| ⚠️ Waarschuwing | Meters buis = 0 | Controleren |
| ⚠️ Waarschuwing | Meters buis > 25m | Controleren |
| ⚠️ Waarschuwing | > 5 bochten | Controleren |
| ⚠️ Waarschuwing | DWA zonder RWA (of omgekeerd) | Controleren |
| ⚠️ Waarschuwing | Geen putnummer | Controleren |

---

## VEELGESTELDE VRAGEN

**V: Kan ik het formulier aanpassen?**
A: Ja, open het formulier via de bewerkings-URL en voeg velden toe/verwijder. Pas dan ook de kolom-mapping in `vlario_filler.py` aan (dict `FORM_COLUMNS`).

**V: Wat als Olivier geen internet heeft op de werf?**
A: Google Forms werkt offline via de Google Forms app. Data wordt gesynchroniseerd zodra er weer verbinding is.

**V: Hoe zit het met de foto's?**
A: Foto's worden apart beheerd (Google Drive gedeelde map). Het Python script vult de hoeveelheden in; foto's moeten manueel in de fiches geplakt worden via het knipprogramma (VLARIO-vereiste om bestandsgrootte beperkt te houden).

**V: Werkt de VLARIO macro nog na het vullen met Python?**
A: Ja, het script bewaart de VBA macro's (`keep_vba=True`). De macro's draaien normaal in Excel.

**V: Kan ik meerdere fases in één keer draaien?**
A: Ja, maar de VLARIO macro kan maar 1× per tabblad per bestand draaien. Draai het script dus per fase met `--fase` filter en krijg per fase een apart .xlsm bestand.
