import { useState } from "react";

const PIPELINE_STAGES = [
  { id: "capture", title: "1. Data Capture op Werf", icon: "📱", color: "orange" },
  { id: "transport", title: "2. Data Transport", icon: "☁️", color: "blue" },
  { id: "processing", title: "3. Verwerking & Validatie", icon: "⚙️", color: "purple" },
  { id: "template", title: "4. VLARIO Template Vullen", icon: "📊", color: "green" },
  { id: "tools", title: "5. Toolkeuze & Setup", icon: "🔧", color: "gray" },
];

function Badge({ children, color = "blue" }) {
  const c = {
    blue: "bg-blue-100 text-blue-800", orange: "bg-orange-100 text-orange-800",
    green: "bg-green-100 text-green-800", purple: "bg-purple-100 text-purple-800",
    red: "bg-red-100 text-red-800", gray: "bg-gray-100 text-gray-700",
    amber: "bg-amber-100 text-amber-800", teal: "bg-teal-100 text-teal-800",
  };
  return <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${c[color]}`}>{children}</span>;
}

function DataFlowDiagram() {
  return (
    <div className="bg-gradient-to-r from-orange-50 via-blue-50 via-purple-50 to-green-50 rounded-2xl p-5 border border-gray-200">
      <h3 className="text-sm font-bold text-gray-700 mb-4 text-center">COMPLETE DATA PIPELINE: WERF → VLARIO FICHE</h3>
      <div className="flex flex-col md:flex-row items-stretch gap-2">
        {[
          { icon: "📱", title: "WERF", sub: "Smartphone / Tablet / GPS", color: "bg-orange-500", items: ["Foto's", "Metingen", "Fittingen", "Coördinaten"] },
          { icon: "→", isArrow: true },
          { icon: "☁️", title: "SYNC", sub: "Google Forms / Sheets / Drive", color: "bg-blue-500", items: ["Auto-upload", "Validatie", "Tijdstempel"] },
          { icon: "→", isArrow: true },
          { icon: "⚙️", title: "VERWERKING", sub: "Python script / Apps Script", color: "bg-purple-500", items: ["Data mapping", "Hoeveelheden optellen", "Fiche generatie"] },
          { icon: "→", isArrow: true },
          { icon: "📊", title: "VLARIO .xlsm", sub: "Template + Macro + PDF", color: "bg-green-500", items: ["Overzichtslijst", "Individuele fiches", "PDF export"] },
        ].map((block, i) =>
          block.isArrow ? (
            <div key={i} className="flex items-center justify-center text-gray-300 text-2xl font-bold px-1 hidden md:flex">→</div>
          ) : (
            <div key={i} className="flex-1 bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
              <div className={`${block.color} text-white p-2 text-center`}>
                <div className="text-lg">{block.icon}</div>
                <div className="text-xs font-bold">{block.title}</div>
              </div>
              <div className="p-2.5 text-center">
                <p className="text-xs text-gray-400 mb-1.5">{block.sub}</p>
                {block.items.map((item) => (
                  <div key={item} className="text-xs text-gray-600 py-0.5">{item}</div>
                ))}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}

function CaptureMethod({ title, icon, badge, badgeColor, pros, cons, steps, effort, cost, recommended }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`bg-white rounded-xl border ${recommended ? "border-green-300 ring-2 ring-green-100" : "border-gray-200"} overflow-hidden`}>
      {recommended && (
        <div className="bg-green-500 text-white text-xs font-bold text-center py-1">★ AANBEVOLEN VOOR COLAS</div>
      )}
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{icon}</span>
            <div>
              <h4 className="font-bold text-gray-800 text-sm">{title}</h4>
              <Badge color={badgeColor}>{badge}</Badge>
            </div>
          </div>
          <div className="text-right text-xs text-gray-400">
            <div>Inspanning: {effort}</div>
            <div>Kost: {cost}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-green-600 font-medium">✓ Voordelen</span>
            {pros.map((p,i) => <p key={i} className="text-gray-600 mt-0.5">• {p}</p>)}
          </div>
          <div>
            <span className="text-red-500 font-medium">✗ Nadelen</span>
            {cons.map((c,i) => <p key={i} className="text-gray-600 mt-0.5">• {c}</p>)}
          </div>
        </div>
        <button onClick={() => setOpen(!open)} className="text-xs text-blue-600 font-medium hover:underline">
          {open ? "▼ Verberg stappen" : "▶ Toon concrete stappen"}
        </button>
        {open && (
          <ol className="space-y-1.5 text-xs text-gray-600 bg-gray-50 rounded-lg p-3">
            {steps.map((s, i) => (
              <li key={i} className="flex gap-2">
                <span className="bg-gray-200 rounded-full w-4 h-4 flex items-center justify-center flex-shrink-0 text-xs font-bold">{i + 1}</span>
                <span>{s}</span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}

function StageCapture() {
  return (
    <div className="space-y-4">
      <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-sm text-orange-800">
        <strong>Het probleem:</strong> Op de werf staan Olivier (Puurs) of Junior (Zwijndrecht) bij een open sleuf. Ze moeten snel en foutloos alle metingen, fittingen en foto's vastleggen — liefst zonder papier dat nat wordt of kwijtraakt.
      </div>

      <h4 className="font-bold text-gray-700 text-sm">3 methodes om data op de werf vast te leggen:</h4>

      <div className="grid grid-cols-1 gap-4">
        <CaptureMethod
          title="Google Forms op Smartphone"
          icon="📱"
          badge="Laagdrempelig"
          badgeColor="green"
          effort="⚡ Laag"
          cost="€0 (gratis)"
          recommended={true}
          pros={[
            "Gratis, meteen te gebruiken",
            "Werkt offline (Google Forms app)",
            "Foto's direct vanuit formulier",
            "Dropdown keuzelijsten = minder fouten",
            "Data komt direct in Google Sheets",
            "Olivier & Junior kennen smartphones",
          ]}
          cons={[
            "Klein scherm voor veel velden",
            "Foto-upload kan traag zijn op werf",
            "Geen GPS-koppeling met Topcon",
            "Manuele invoer afstanden",
          ]}
          steps={[
            "JIJ maakt een Google Form aan met alle VLARIO-velden (eenmalig, ik kan dit voor je bouwen)",
            "Formulier bevat: adres, putnummers, afstanden, dropdown voor fittingen (bocht 15/30/45/90, stop, reductie, etc.), foto-upload velden",
            "Olivier/Junior openen het formulier op hun smartphone via link of QR-code",
            "Per aansluiting vullen ze het formulier in terwijl ze bij de sleuf staan",
            "Ze maken de 4 foto's direct vanuit het formulier (camera opent automatisch)",
            "Bij verzenden → data komt in een Google Sheet, foto's in Google Drive",
            "JIJ controleert de Sheet op kantoor en exporteert naar VLARIO template",
          ]}
        />

        <CaptureMethod
          title="Werfformulier op Tablet (KoBoToolbox / ODK)"
          icon="📋"
          badge="Professioneel"
          badgeColor="blue"
          effort="⚡⚡ Gemiddeld"
          cost="€0 (open source)"
          recommended={false}
          pros={[
            "Groter scherm = beter overzicht",
            "Kan GPS-positie automatisch loggen",
            "Conditional logic (toon kolk-velden alleen bij kolk)",
            "Werkt 100% offline",
            "Professionele data-export (CSV/XLS)",
          ]}
          cons={[
            "Tablet nodig op werf (val/stof risico)",
            "Opzet kost meer tijd (eenmalig)",
            "Extra tool om te leren voor ploeg",
          ]}
          steps={[
            "Maak een KoBoToolbox account aan (gratis, humanitarian/open source tool)",
            "Bouw het formulier met alle VLARIO-velden + conditionele logica",
            "Installeer KoBoCollect app op tablet(s)",
            "Download formulier voor offline gebruik",
            "Ploeg vult per aansluiting het formulier in op de werf",
            "GPS-coördinaten worden automatisch meegenomen (minder nauwkeurig dan Topcon, ~3-5m)",
            "Bij wifi: data synct naar KoBoToolbox server",
            "Export als CSV/XLS → import in VLARIO template",
          ]}
        />

        <CaptureMethod
          title="Topcon Hyper GPS + Papieren Werfbon"
          icon="📡"
          badge="Nauwkeurigst"
          badgeColor="purple"
          effort="⚡⚡⚡ Hoog"
          cost="Bestaand GPS-materiaal"
          recommended={false}
          pros={[
            "Meest nauwkeurige coördinaten (±1-2 cm)",
            "Topcon al beschikbaar bij Colas",
            "Lambert72 direct vanuit toestel",
            "Bewezen workflow voor landmeters",
          ]}
          cons={[
            "GPS = enkel coördinaten, niet de fittingen/foto's",
            "Papieren bon kwijtraken/nat/onleesbaar",
            "Dubbele invoer: papier → Excel",
            "GPS-operator niet altijd beschikbaar",
          ]}
          steps={[
            "Landmeter/GPS-operator meet alle HA-putje deksels met Topcon Hyper",
            "Exporteert punten als CSV: equipmentnr, X, Y, Z (Lambert72/TAW)",
            "APART: ploeg vult papieren werfbon in per aansluiting",
            "Werfbon bevat: fittingen, meters buis, type aansluiting, afstanden",
            "Foto's apart nemen met smartphone",
            "Op kantoor: werfbon + GPS-data + foto's samenvoegen",
            "Alles manueel invoeren in VLARIO template",
            "RISICO: meeste fouten ontstaan bij de manuele overzetting",
          ]}
        />
      </div>
    </div>
  );
}

function StageTransport() {
  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-800">
        <strong>Van werf naar kantoor:</strong> Hoe komt de ingevulde data bij jou terecht zodat je het kunt verwerken?
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
          <h4 className="font-bold text-gray-800 text-sm flex items-center gap-2">
            <span className="text-xl">📊</span> Google Forms → Google Sheets (AANBEVOLEN)
          </h4>
          <div className="bg-green-50 rounded-lg p-3 text-xs text-gray-600 space-y-2">
            <p><strong>Automatisch:</strong> Elke inzending maakt een nieuwe rij in Google Sheets</p>
            <p><strong>Structuur:</strong></p>
            <div className="font-mono bg-white rounded p-2 text-xs overflow-x-auto">
              <div className="text-gray-400">Tijdstempel | Straat | Nr | DWA/RWA | Put_af | Put_op | Afstand_put | ...</div>
              <div>28/02/2026 | Burchtsestraat | 12 | DWA | P12 | P13 | 8.50 | ...</div>
              <div>28/02/2026 | Burchtsestraat | 12 | RWA | P12 | P13 | 8.50 | ...</div>
            </div>
            <p><strong>Foto's:</strong> Komen in een Google Drive map, gelinkt aan de Sheet-rij</p>
            <p><strong>Real-time:</strong> Jij ziet op kantoor meteen wanneer Olivier of Junior iets invult</p>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
          <h4 className="font-bold text-gray-800 text-sm flex items-center gap-2">
            <span className="text-xl">📡</span> Topcon GPS → CSV Export
          </h4>
          <div className="bg-purple-50 rounded-lg p-3 text-xs text-gray-600 space-y-2">
            <p><strong>Workflow:</strong> Topcon FC-6000 → USB/Bluetooth → Laptop → CSV file</p>
            <p><strong>Export formaat:</strong></p>
            <div className="font-mono bg-white rounded p-2 text-xs overflow-x-auto">
              <div className="text-gray-400">PuntID | X_Lambert72 | Y_Lambert72 | Z_TAW | Code</div>
              <div>123456789 | 151234.56 | 203456.78 | 5.432 | HA_DWA</div>
            </div>
            <p><strong>Timing:</strong> Export 1x per dag of per fase</p>
            <p><strong>Import:</strong> CSV rechtstreeks in Google Sheet of VLARIO template plakken</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
        <h4 className="font-bold text-gray-800 text-sm">Mappenstructuur (Google Drive / SharePoint)</h4>
        <div className="font-mono text-xs bg-gray-50 rounded-lg p-3 text-gray-600">
          <div>📁 VLARIO_Huisaansluitfiches/</div>
          <div>&nbsp;&nbsp;📁 Puurs/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;📁 Fase_1/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📊 VLARIO_template_Puurs_F1.xlsm</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📊 Data_Puurs_F1.gsheet (← Google Forms response)</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📁 Fotos/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📷 Burchtsestraat_12_DWA_foto1.jpg</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📷 Burchtsestraat_12_DWA_foto2.jpg</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📷 ...</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📁 GPS_export/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📄 Topcon_export_20260228.csv</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📁 PDF_fiches/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;📄 GEM=PUU_projectnr=23.456_..._AB-HA-fiche.pdf</div>
          <div>&nbsp;&nbsp;📁 Zwijndrecht/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;📁 Fase_1_Burchtsestraat/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;📁 Fase_2_Burchtsestraat/</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;📁 ...</div>
        </div>
      </div>
    </div>
  );
}

function StageProcessing() {
  return (
    <div className="space-y-4">
      <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-sm text-purple-800">
        <strong>De automatisatie-stap:</strong> Een Python script of Google Apps Script leest de Google Sheet en vult het VLARIO template automatisch in. Geen manueel kopiëren meer.
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-green-200 p-4 space-y-3 ring-2 ring-green-100">
          <div className="bg-green-500 text-white text-xs font-bold text-center py-1 -mx-4 -mt-4 rounded-t-xl mb-2">★ AANBEVOLEN</div>
          <h4 className="font-bold text-gray-800 text-sm">Optie A: Python Script (openpyxl)</h4>
          <p className="text-xs text-gray-500">Draait op jouw laptop of een server. Leest Google Sheets CSV/Excel en schrijft naar VLARIO .xlsm template.</p>
          <div className="bg-gray-50 rounded-lg p-3 font-mono text-xs text-gray-600 space-y-1">
            <p className="text-green-600"># Pseudo-code van het script</p>
            <p>1. Lees Google Sheet (download als .xlsx)</p>
            <p>2. Lees GPS CSV (Topcon export)</p>
            <p>3. Open VLARIO template (.xlsm)</p>
            <p>4. Per adres in Sheet:</p>
            <p>&nbsp;&nbsp;→ Vul "Algemene gegevens" tabblad</p>
            <p>&nbsp;&nbsp;→ Voeg rij toe in "Project HA" (DWA+RWA)</p>
            <p>&nbsp;&nbsp;→ Voeg rij toe in "Project kolk" (indien kolk)</p>
            <p>&nbsp;&nbsp;→ Koppel GPS coördinaten via equipmentnr</p>
            <p>&nbsp;&nbsp;→ Vul diameter, materiaal, hoeveelheden</p>
            <p>5. Sla op als nieuwe .xlsm per fase</p>
            <p>6. → Macro draaien = fiches aanmaken</p>
            <p>7. → Foto's invoegen per fiche</p>
            <p>8. → PDF macro draaien = klaar</p>
          </div>
          <div className="flex flex-wrap gap-1">
            <Badge color="green">Flexibel</Badge>
            <Badge color="green">Herhaalbaar</Badge>
            <Badge color="green">Foutvrij</Badge>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
          <h4 className="font-bold text-gray-800 text-sm">Optie B: Google Apps Script</h4>
          <p className="text-xs text-gray-500">Draait in de cloud, direct gekoppeld aan je Google Sheet. Geen installatie nodig.</p>
          <div className="bg-gray-50 rounded-lg p-3 font-mono text-xs text-gray-600 space-y-1">
            <p className="text-blue-600">// Trigger: bij nieuwe Form-inzending</p>
            <p>function onFormSubmit(e) {"{"}</p>
            <p>&nbsp;&nbsp;// Valideer data (verplichte velden)</p>
            <p>&nbsp;&nbsp;// Markeer rij als "gevalideerd"</p>
            <p>&nbsp;&nbsp;// Stuur notificatie naar Jolien</p>
            <p>&nbsp;&nbsp;// Bereken tussentotalen</p>
            <p>{"}"}</p>
            <br/>
            <p className="text-blue-600">// Handmatig: export naar VLARIO</p>
            <p>function exportNaarVLARIO() {"{"}</p>
            <p>&nbsp;&nbsp;// Download template</p>
            <p>&nbsp;&nbsp;// Vul data in via SpreadsheetApp</p>
            <p>&nbsp;&nbsp;// Sla op in Drive</p>
            <p>{"}"}</p>
          </div>
          <div className="flex flex-wrap gap-1">
            <Badge color="blue">Cloud-based</Badge>
            <Badge color="blue">Auto-trigger</Badge>
            <Badge color="amber">Beperkt .xlsm support</Badge>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
        <h4 className="font-bold text-gray-800 text-sm">Validatieregels (automatisch controleren)</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-red-50 rounded-lg p-3">
            <p className="font-semibold text-red-700 mb-1">❌ Blokkerende fouten</p>
            <p className="text-gray-600">• Geen straatnaam ingevuld</p>
            <p className="text-gray-600">• Geen equipmentnummer</p>
            <p className="text-gray-600">• DWA rij zonder RWA rij (of omgekeerd)</p>
            <p className="text-gray-600">• Geen putnummers</p>
            <p className="text-gray-600">• Meters buis = 0</p>
          </div>
          <div className="bg-amber-50 rounded-lg p-3">
            <p className="font-semibold text-amber-700 mb-1">⚠️ Waarschuwingen</p>
            <p className="text-gray-600">• Meters buis {">"} 20m (ongewoon)</p>
            <p className="text-gray-600">• Meer dan 5 bochten (check)</p>
            <p className="text-gray-600">• Geen foto's geüpload</p>
            <p className="text-gray-600">• GPS coördinaten ontbreken</p>
            <p className="text-gray-600">• Afstand put {">"} 50m</p>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <p className="font-semibold text-green-700 mb-1">✅ Auto-berekeningen</p>
            <p className="text-gray-600">• Totaal fittingen per type</p>
            <p className="text-gray-600">• Totaal meters buis</p>
            <p className="text-gray-600">• Filenaam generatie</p>
            <p className="text-gray-600">• DWA+RWA koppeling check</p>
            <p className="text-gray-600">• Volledigheid score %</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function StageTemplate() {
  return (
    <div className="space-y-4">
      <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-green-800">
        <strong>De mapping:</strong> Welk veld uit Google Forms/Sheet komt in welke cel van het VLARIO template?
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
          <h4 className="font-bold text-gray-700 text-sm">Veldmapping: Google Form → VLARIO Template</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-3 py-2 text-left font-semibold text-gray-600">Google Form Veld</th>
                <th className="px-3 py-2 text-left font-semibold text-gray-600">VLARIO Tabblad</th>
                <th className="px-3 py-2 text-left font-semibold text-gray-600">VLARIO Kolom/Cel</th>
                <th className="px-3 py-2 text-left font-semibold text-gray-600">Type</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {[
                ["Straatnaam", "Project HA", "Kolom A (Straat)", "Tekst"],
                ["Huisnummer", "Project HA", "Kolom B (Huisnr)", "Getal"],
                ["Equipmentnummer", "Project HA", "Kolom C", "Getal (9 cijfers)"],
                ["Aard water (DWA/RWA/GEM)", "Project HA", "Kolom D", "Dropdown"],
                ["Soort (HA/WA/kolk)", "Project HA/WA/kolk", "Kolom E", "Dropdown"],
                ["Diameter (mm)", "Project HA + Fiche", "Kolom F + Fiche A18", "Dropdown (160)"],
                ["Materiaal", "Project HA + Fiche", "Kolom G + Fiche A17", "Dropdown (PVC)"],
                ["Put stroomafwaarts", "Fiche", "Cel A9 (deel 1)", "Tekst"],
                ["Put stroomopwaarts", "Fiche", "Cel A9 (deel 2)", "Tekst"],
                ["Afstand tot stroomaf. put (m)", "Fiche", "Cel G10 (DWA) / I10 (RWA)", "Getal"],
                ["Ligging HA-putje", "Fiche", "Cel G11 / I11", "Keuzelijst"],
                ["Diepte HA-putje (m)", "Fiche", "Cel G12 / I12", "Getal"],
                ["Type aansluiting", "Fiche", "Cel G19 / I19", "Keuzelijst"],
                ["Hoek aansluiting", "Fiche", "Cel G34 / I34", "Keuzelijst"],
                ["Mof (st)", "Project HA Kol. K + Fiche G20", "Kolom K + Fiche", "Getal"],
                ["Buis (m)", "Project HA Kol. L + Fiche G21", "Kolom L + Fiche", "Getal"],
                ["Bocht (st) — 15/30/45/90", "Project HA Kol. M + Fiche G22", "Kolom M + Fiche", "Getal"],
                ["Y/T-stuk (st)", "Project HA Kol. N + Fiche G23", "Kolom N", "Getal"],
                ["Krimpmof (st)", "Project HA Kol. O + Fiche G24", "Kolom O", "Getal"],
                ["Koppelstuk (st)", "Project HA Kol. P + Fiche G25", "Kolom P", "Getal"],
                ["Reductie (st)", "Project HA Kol. Q + Fiche G26", "Kolom Q", "Getal"],
                ["Stop (st)", "Project HA Kol. R + Fiche G27", "Kolom R", "Getal"],
                ["HA-putje Ø (mm)", "Project HA Kol. T + Fiche G29", "Kolom T + Fiche", "Getal"],
                ["Terugslagklep (ja/nee)", "Project HA Kol. U + Fiche G30", "Kolom U + Fiche", "Dropdown"],
                ["Afstand DWA putje horiz. (letter+m)", "Fiche", "Cel B54 + E54", "Letter + Getal"],
                ["Afstand DWA putje vert. (letter+m)", "Fiche", "Cel B55 + E55", "Letter + Getal"],
                ["Afstand RWA putje horiz. (letter+m)", "Fiche", "Cel H54 + J54", "Letter + Getal"],
                ["Afstand RWA putje vert. (letter+m)", "Fiche", "Cel H55 + J55", "Letter + Getal"],
                ["X coördinaat (Lambert72)", "Project HA", "Kolom H", "Getal (6 dec)"],
                ["Y coördinaat (Lambert72)", "Project HA", "Kolom I", "Getal (6 dec)"],
                ["Z coördinaat (TAW)", "Project HA", "Kolom J", "Getal (3 dec)"],
                ["Foto 1 (boring)", "Fiche", "Rij 60-61 (DWA) / F60-61 (RWA)", "Afbeelding"],
                ["Foto 2 (plaatsing)", "Fiche", "Rij 62-63", "Afbeelding"],
                ["Foto 3 (verbinding privé)", "Fiche", "Rij 69-70", "Afbeelding"],
                ["Foto 4 (omhulling)", "Fiche", "Rij 71-72", "Afbeelding"],
              ].map(([form, tab, cel, type], i) => (
                <tr key={i} className="hover:bg-gray-50">
                  <td className="px-3 py-1.5 font-medium text-gray-700">{form}</td>
                  <td className="px-3 py-1.5 text-gray-500">{tab}</td>
                  <td className="px-3 py-1.5 font-mono text-gray-500">{cel}</td>
                  <td className="px-3 py-1.5"><Badge color={type === "Dropdown" || type === "Keuzelijst" ? "blue" : type === "Afbeelding" ? "purple" : "gray"}>{type}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        <strong>Let op:</strong> De VLARIO macro kan maar 1× draaien per overzichtslijst per bestand. Werk dus per fase in een apart bestand. De hoeveelheden in de fiches worden automatisch teruggekoppeld naar de overzichtstabel.
      </div>
    </div>
  );
}

function StageTools() {
  return (
    <div className="space-y-4">
      <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm text-gray-700">
        <strong>Concrete setup — wat moet je doen om morgen te starten?</strong>
      </div>

      <div className="space-y-3">
        {[
          {
            nr: "1",
            title: "Google Form aanmaken (eenmalig, ~2 uur)",
            color: "bg-orange-500",
            details: [
              "Ik kan dit volledig voor je bouwen in de volgende stap",
              "Alle VLARIO-velden als Form-vragen met juiste types",
              "Dropdown keuzelijsten (ligging, hoek, type aansluiting, ja/nee)",
              "Foto-upload velden (4 per DWA + 4 per RWA)",
              "Conditionele secties: kolk-velden alleen zichtbaar bij soort=kolk",
              "QR-code genereren zodat Olivier/Junior het formulier snel kunnen openen",
            ],
          },
          {
            nr: "2",
            title: "Google Sheet koppelen + dashboard (eenmalig, ~1 uur)",
            color: "bg-blue-500",
            details: [
              "Form-responses Sheet krijgt extra tabbladen voor overzicht",
              "Pivot-tabellen voor totaal hoeveelheden per materiaal",
              "Voortgangspercentage per fase (hoeveel fiches compleet?)",
              "Conditional formatting: rood = incompleet, groen = klaar",
              "Filter op werf (Puurs/Zwijndrecht) en fase",
            ],
          },
          {
            nr: "3",
            title: "Python export-script (eenmalig, ~3 uur)",
            color: "bg-purple-500",
            details: [
              "Ik kan dit script voor je schrijven",
              "Leest Google Sheet data (download als .xlsx of via API)",
              "Leest Topcon GPS CSV export",
              "Opent VLARIO .xlsm template (jouw bijgevoegde bestand)",
              "Vult alle tabbladen automatisch in",
              "Genereert 1 bestand per fase, klaar om macro te draaien",
              "Draait in 30 seconden voor 50+ aansluitingen",
            ],
          },
          {
            nr: "4",
            title: "Olivier & Junior briefen (~30 min)",
            color: "bg-green-500",
            details: [
              "QR-code op A4 ophangen in werfkeet",
              "Laat ze 1 test-aansluiting invullen samen met jou",
              "Afspraak: formulier invullen TIJDENS de aanleg (niet achteraf)",
              "Foto's: 4 momenten = 4 foto's, direct vanuit formulier",
              "Bij twijfel over een veld: invullen wat ze weten, rest markeren",
            ],
          },
          {
            nr: "5",
            title: "Wekelijkse routine op kantoor (~1 uur/week)",
            color: "bg-teal-500",
            details: [
              "Check Google Sheet op nieuwe inzendingen",
              "Valideer: ontbrekende velden? Onlogische waarden?",
              "Vraag Olivier/Junior om aanvulling waar nodig",
              "Maandelijks of per fase: Python script draaien → VLARIO template",
              "Macro draaien → fiches aanmaken → foto's invoegen → PDF",
              "Opladen naar projectmap → klaar voor rioolbeheerder",
            ],
          },
        ].map((step) => (
          <div key={step.nr} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className={`${step.color} text-white px-4 py-2 flex items-center gap-2`}>
              <span className="bg-white/20 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">{step.nr}</span>
              <span className="font-semibold text-sm">{step.title}</span>
            </div>
            <div className="p-4">
              <ul className="space-y-1">
                {step.details.map((d, i) => (
                  <li key={i} className="text-xs text-gray-600 flex gap-2">
                    <span className="text-gray-300 flex-shrink-0">•</span>
                    {d}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-green-50 border border-green-300 rounded-xl p-5 space-y-3">
        <h4 className="font-bold text-green-800">Volgende stappen — wat wil je dat ik bouw?</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            { icon: "📱", title: "Google Form", desc: "Volledig VLARIO-conform formulier met alle velden, dropdowns en foto-upload" },
            { icon: "🐍", title: "Python Script", desc: "Sheet → VLARIO .xlsm converter met GPS-import en foto-plaatsing" },
            { icon: "📊", title: "Dashboard Sheet", desc: "Overzicht per werf/fase met voortgang, hoeveelheden en validatie" },
          ].map((item) => (
            <div key={item.title} className="bg-white rounded-lg border border-green-200 p-3 text-center">
              <div className="text-2xl mb-1">{item.icon}</div>
              <div className="font-semibold text-gray-800 text-sm">{item.title}</div>
              <div className="text-xs text-gray-500 mt-1">{item.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function DataPipeline() {
  const [activeStage, setActiveStage] = useState(0);

  const stageComponents = [
    <StageCapture />,
    <StageTransport />,
    <StageProcessing />,
    <StageTemplate />,
    <StageTools />,
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-blue-50" style={{ fontFamily: "'Segoe UI', -apple-system, sans-serif" }}>
      <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-4">
        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-green-500 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-md">⟶</div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Data Pipeline: Werf → VLARIO Fiche</h1>
              <p className="text-xs text-gray-400">Hoe geraakt de data van de werf in het VLARIO template?</p>
            </div>
          </div>
        </div>

        <DataFlowDiagram />

        <div className="overflow-x-auto">
          <div className="flex gap-1 min-w-max">
            {PIPELINE_STAGES.map((stage, i) => (
              <button
                key={stage.id}
                onClick={() => setActiveStage(i)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all whitespace-nowrap ${
                  i === activeStage
                    ? "bg-blue-600 text-white shadow-md shadow-blue-200"
                    : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
                }`}
              >
                <span>{stage.icon}</span>
                <span className="font-medium">{stage.title}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm min-h-96">
          {stageComponents[activeStage]}
        </div>

        <div className="flex justify-between">
          <button
            onClick={() => setActiveStage(Math.max(0, activeStage - 1))}
            disabled={activeStage === 0}
            className="px-5 py-2.5 bg-white border border-gray-200 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-50 disabled:opacity-40 transition-all"
          >
            ← Vorige
          </button>
          <button
            onClick={() => setActiveStage(Math.min(PIPELINE_STAGES.length - 1, activeStage + 1))}
            disabled={activeStage === PIPELINE_STAGES.length - 1}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 disabled:opacity-40 shadow-md shadow-blue-200 transition-all"
          >
            Volgende →
          </button>
        </div>
      </div>
    </div>
  );
}
