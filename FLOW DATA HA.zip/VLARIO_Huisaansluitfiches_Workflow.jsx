import { useState, useEffect, useRef } from "react";

const STEPS = [
  {
    id: "project",
    title: "1. Projectgegevens",
    icon: "📋",
    desc: "Algemene projectinformatie invullen",
  },
  {
    id: "adressen",
    title: "2. Adressenlijst",
    icon: "🏠",
    desc: "DWA/RWA/Kolk aansluitingen per adres",
  },
  {
    id: "werfdata",
    title: "3. Werfdata Inzameling",
    icon: "📐",
    desc: "Metingen, fittingen & positie op werf",
  },
  {
    id: "fotos",
    title: "4. Foto's (4 per fiche)",
    icon: "📷",
    desc: "VLARIO-conforme foto's per fase",
  },
  {
    id: "coordinaten",
    title: "5. GPS Coördinaten",
    icon: "📡",
    desc: "Lambert XYZ via Topcon Hyper of manueel",
  },
  {
    id: "facturatie",
    title: "6. Facturatie-overzicht",
    icon: "💰",
    desc: "Hoeveelheden & materialen per aansluiting",
  },
  {
    id: "export",
    title: "7. Export & Generatie",
    icon: "📄",
    desc: "VLARIO Excel + PDF per fiche",
  },
];

const FITTING_TYPES = [
  { key: "bocht_15", label: "Bocht 15°", unit: "st", icon: "↗" },
  { key: "bocht_30", label: "Bocht 30°", unit: "st", icon: "↗" },
  { key: "bocht_45", label: "Bocht 45°", unit: "st", icon: "↗" },
  { key: "bocht_90", label: "Bocht 90°", unit: "st", icon: "↱" },
  { key: "stop", label: "Stop", unit: "st", icon: "⊘" },
  { key: "reductie_110_90", label: "Reductie 110→90", unit: "st", icon: "⊃" },
  { key: "reductie_110_130", label: "Reductie 110→130", unit: "st", icon: "⊂" },
  { key: "inlaat", label: "Inlaat/T-stuk", unit: "st", icon: "⊤" },
  { key: "mof", label: "Mof", unit: "st", icon: "═" },
  { key: "krimpmof", label: "Krimpmof", unit: "st", icon: "≡" },
  { key: "koppelstuk", label: "Koppelstuk", unit: "st", icon: "⊞" },
  { key: "y_stuk", label: "Y/T-stuk", unit: "st", icon: "⋔" },
];

const LIGGING_OPTIONS = ["oprit", "voortuin", "berm", "voetpad", "fietspad", "MANUEEL INVULLEN"];
const HOEK_OPTIONS = ["90°", "135°", "180°", "225°", "270°", "NVT"];
const TYPE_AANSLUITING = ["T-buis", "T-stuk", "Y-stuk", "flexibele aansluiting", "aanboring"];
const AARD_WATER = ["DWA", "RWA", "GEM"];
const SOORT = ["HA", "WA", "kolk"];
const MATERIAAL = ["PVC", "PP", "grès"];
const DIAMETER = ["160", "200", "250", "315", "400"];

const FOTO_SPECS = [
  {
    id: 1,
    title: "Boring/opening aansluiting op hoofdriool",
    desc: "Foto van de aanboring of opening op het hoofdriool vóór plaatsing buizen",
    timing: "Bij aanleg aansluiting",
  },
  {
    id: 2,
    title: "Plaatsing buizen, hulpstukken & HA-putje",
    desc: "Vanaf aansluitopening richting putje - alle hulpstukken zichtbaar",
    timing: "Na plaatsing, vóór aanvulling",
  },
  {
    id: 3,
    title: "Verbinding HA-putje ↔ privé-riool",
    desc: "Aansluiting tussen het HA-putje en de bestaande privé-riolering",
    timing: "Bij koppeling privé",
  },
  {
    id: 4,
    title: "Met omhulling (zelfde als foto 2)",
    desc: "Zelfde perspectief als foto 2, maar mét zandbed/omhulling zichtbaar",
    timing: "Na omhulling, vóór dichtmaken",
  },
];

const GPS_METHODS = [
  {
    id: "topcon",
    name: "Topcon Hyper SR/VR (RTK-GPS)",
    icon: "📡",
    accuracy: "±1-2 cm",
    desc: "Real-time kinematic GPS via FLEPOS netwerk. Ideaal voor nauwkeurige Lambert72 coördinaten.",
    workflow: [
      "Start Topcon FC-6000 controller",
      "Verbind met FLEPOS (NTRIP mount: FLEPOS_VRS)",
      "Wacht op FIXED oplossing (< 2cm precisie)",
      "Meet midden deksel HA-putje",
      "Sla punt op met uniek ID (= equipmentnr)",
      "Exporteer als CSV: X(Lambert72), Y(Lambert72), Z(TAW)",
    ],
  },
  {
    id: "manueel",
    name: "Manuele opmeting",
    icon: "📏",
    accuracy: "±5-10 cm",
    desc: "Opmeting t.o.v. gekende punten (putten, gevels). Fallback als geen GPS beschikbaar.",
    workflow: [
      "Meet afstand vanaf 2 gekende referentiepunten",
      "Noteer afstand tot stroomafwaartse put (langs as riool)",
      "Noteer afstand tot rechtergevel / rooilijn",
      "Gebruik plan om Lambert72 af te leiden",
      "Z-peil: gebruik nivelleringstoestel of bekende putdeksels",
      "Noteer alle metingen op werfformulier",
    ],
  },
];

function Badge({ children, color = "blue" }) {
  const colors = {
    blue: "bg-blue-100 text-blue-800 border-blue-200",
    amber: "bg-amber-100 text-amber-800 border-amber-200",
    green: "bg-green-100 text-green-800 border-green-200",
    orange: "bg-orange-100 text-orange-800 border-orange-200",
    red: "bg-red-100 text-red-800 border-red-200",
    gray: "bg-gray-100 text-gray-700 border-gray-200",
    purple: "bg-purple-100 text-purple-800 border-purple-200",
  };
  return (
    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${colors[color]}`}>
      {children}
    </span>
  );
}

function FieldGroup({ label, help, children, required }) {
  return (
    <div className="space-y-1">
      <label className="text-sm font-medium text-gray-700 flex items-center gap-1.5">
        {label}
        {required && <span className="text-red-500">*</span>}
      </label>
      {help && <p className="text-xs text-gray-400">{help}</p>}
      {children}
    </div>
  );
}

function Select({ options, value, onChange, placeholder }) {
  return (
    <select
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
    >
      <option value="">{placeholder || "Selecteer..."}</option>
      {options.map((o) => (
        <option key={o} value={o}>{o}</option>
      ))}
    </select>
  );
}

function Input({ type = "text", ...props }) {
  return (
    <input
      type={type}
      {...props}
      className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
    />
  );
}

function StepProjectgegevens({ data, setData }) {
  const update = (k, v) => setData({ ...data, [k]: v });
  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-800">
        <strong>VLARIO Template — Tabblad "Algemene gegevens"</strong>
        <p className="mt-1 text-blue-600">Blauwe velden = rioolbeheerder invult vóór overdracht aan aannemer. Gele velden = aannemer vult in.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4 p-4 bg-blue-50/50 rounded-xl border border-blue-100">
          <h4 className="font-semibold text-blue-900 text-sm flex items-center gap-2">
            <Badge color="blue">Rioolbeheerder</Badge>
          </h4>
          <FieldGroup label="Naam rioolbeheerder" required>
            <Input value={data.rioolbeheerder || ""} onChange={(e) => update("rioolbeheerder", e.target.value)} placeholder="bv. Aquafin / Fluvius / Pidpa" />
          </FieldGroup>
          <FieldGroup label="Projectnummer rioolbeheerder" required>
            <Input value={data.projectnr_rb || ""} onChange={(e) => update("projectnr_rb", e.target.value)} placeholder="bv. 23.456" />
          </FieldGroup>
          <FieldGroup label="Projectnaam" required>
            <Input value={data.projectnaam || ""} onChange={(e) => update("projectnaam", e.target.value)} placeholder="bv. Gescheiden riolering Burchtsestraat" />
          </FieldGroup>
          <FieldGroup label="Gemeente" required>
            <Input value={data.gemeente || ""} onChange={(e) => update("gemeente", e.target.value)} placeholder="bv. Zwijndrecht / Puurs" />
          </FieldGroup>
          <FieldGroup label="Gemeentecode fiche">
            <Input value={data.gemeentecode || ""} onChange={(e) => update("gemeentecode", e.target.value)} placeholder="bv. ZWI / PUU" />
          </FieldGroup>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-4">
            <h4 className="font-semibold text-gray-700 text-sm">Bouwheer</h4>
            <FieldGroup label="Naam bouwheer">
              <Input value={data.bouwheer || ""} onChange={(e) => update("bouwheer", e.target.value)} />
            </FieldGroup>
            <FieldGroup label="Projectnummer bouwheer">
              <Input value={data.projectnr_bh || ""} onChange={(e) => update("projectnr_bh", e.target.value)} />
            </FieldGroup>
          </div>
          <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 space-y-4">
            <h4 className="font-semibold text-amber-900 text-sm flex items-center gap-2">
              <Badge color="amber">Aannemer</Badge>
            </h4>
            <FieldGroup label="Naam aannemer" required>
              <Input value={data.aannemer || "Colas Belgium"} onChange={(e) => update("aannemer", e.target.value)} />
            </FieldGroup>
            <FieldGroup label="Projectnummer aannemer">
              <Input value={data.projectnr_an || ""} onChange={(e) => update("projectnr_an", e.target.value)} />
            </FieldGroup>
            <FieldGroup label="Werfleider" required>
              <Input value={data.werfleider || ""} onChange={(e) => update("werfleider", e.target.value)} placeholder="bv. Olivier (Puurs) / Junior (Zwijndrecht)" />
            </FieldGroup>
          </div>
        </div>
      </div>
    </div>
  );
}

function StepAdressen({ data, setData }) {
  const [aansluitingen, setAansluitingen] = useState(data.aansluitingen || []);
  const addRow = () => {
    const newRow = {
      id: Date.now(),
      straat: "",
      huisnr: "",
      equipmentnr: "",
      aard: "DWA",
      soort: "HA",
      diameter: "160",
      materiaal: "PVC",
    };
    const updated = [...aansluitingen, newRow];
    setAansluitingen(updated);
    setData({ ...data, aansluitingen: updated });
  };
  const addPair = () => {
    const ts = Date.now();
    const base = { straat: "", huisnr: "", equipmentnr: "", soort: "HA", diameter: "160", materiaal: "PVC" };
    const updated = [
      ...aansluitingen,
      { ...base, id: ts, aard: "DWA" },
      { ...base, id: ts + 1, aard: "RWA" },
    ];
    setAansluitingen(updated);
    setData({ ...data, aansluitingen: updated });
  };
  const updateRow = (id, key, val) => {
    const updated = aansluitingen.map((r) => (r.id === id ? { ...r, [key]: val } : r));
    setAansluitingen(updated);
    setData({ ...data, aansluitingen: updated });
  };
  const removeRow = (id) => {
    const updated = aansluitingen.filter((r) => r.id !== id);
    setAansluitingen(updated);
    setData({ ...data, aansluitingen: updated });
  };

  return (
    <div className="space-y-4">
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        <strong>VLARIO Template — Tabbladen "Project HA" / "Project WA" / "Project kolk"</strong>
        <p className="mt-1 text-amber-600">Elk adres krijgt 2 rijen: 1× DWA + 1× RWA. Bij gescheiden riolering (Puurs/Zwijndrecht) altijd beide invullen. Kolken = enkel RWA.</p>
      </div>

      <div className="flex gap-2">
        <button onClick={addPair} className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors font-medium">
          + DWA/RWA Paar toevoegen
        </button>
        <button onClick={addRow} className="px-4 py-2 bg-gray-200 text-gray-700 text-sm rounded-lg hover:bg-gray-300 transition-colors font-medium">
          + Enkele rij
        </button>
      </div>

      {aansluitingen.length === 0 ? (
        <div className="text-center py-12 text-gray-400 border-2 border-dashed rounded-xl">
          <p className="text-lg mb-1">Nog geen aansluitingen</p>
          <p className="text-sm">Voeg een DWA/RWA paar toe per adres</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-gray-200">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                {["Straat", "Nr", "Equipmentnr", "Aard", "Soort", "Ø mm", "Materiaal", ""].map((h) => (
                  <th key={h} className="px-3 py-2 text-left font-medium text-gray-600 text-xs whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {aansluitingen.map((r) => (
                <tr key={r.id} className={`hover:bg-gray-50 ${r.aard === "RWA" ? "bg-blue-50/30" : r.aard === "DWA" ? "bg-orange-50/30" : "bg-green-50/30"}`}>
                  <td className="px-2 py-1"><Input value={r.straat} onChange={(e) => updateRow(r.id, "straat", e.target.value)} placeholder="Straatnaam" /></td>
                  <td className="px-2 py-1 w-16"><Input value={r.huisnr} onChange={(e) => updateRow(r.id, "huisnr", e.target.value)} placeholder="Nr" /></td>
                  <td className="px-2 py-1"><Input value={r.equipmentnr} onChange={(e) => updateRow(r.id, "equipmentnr", e.target.value)} placeholder="123456789" /></td>
                  <td className="px-2 py-1 w-20"><Select options={AARD_WATER} value={r.aard} onChange={(v) => updateRow(r.id, "aard", v)} /></td>
                  <td className="px-2 py-1 w-20"><Select options={SOORT} value={r.soort} onChange={(v) => updateRow(r.id, "soort", v)} /></td>
                  <td className="px-2 py-1 w-20"><Select options={DIAMETER} value={r.diameter} onChange={(v) => updateRow(r.id, "diameter", v)} /></td>
                  <td className="px-2 py-1 w-20"><Select options={MATERIAAL} value={r.materiaal} onChange={(v) => updateRow(r.id, "materiaal", v)} /></td>
                  <td className="px-2 py-1 w-10">
                    <button onClick={() => removeRow(r.id)} className="text-red-400 hover:text-red-600 text-lg">×</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="text-xs text-gray-400">Totaal: {aansluitingen.length} rijen — {aansluitingen.filter((r) => r.soort === "HA").length} HA, {aansluitingen.filter((r) => r.soort === "WA").length} WA, {aansluitingen.filter((r) => r.soort === "kolk").length} kolken</p>
    </div>
  );
}

function StepWerfdata({ data, setData }) {
  const [selected, setSelected] = useState(null);
  const aansluitingen = data.aansluitingen || [];
  const grouped = {};
  aansluitingen.forEach((a) => {
    const key = `${a.straat || "?"}_${a.huisnr || "?"}`;
    if (!grouped[key]) grouped[key] = { straat: a.straat, huisnr: a.huisnr, items: [] };
    grouped[key].items.push(a);
  });

  const werfdata = data.werfdata || {};
  const updateWerf = (adresKey, field, val) => {
    const updated = { ...werfdata, [adresKey]: { ...(werfdata[adresKey] || {}), [field]: val } };
    setData({ ...data, werfdata: updated });
  };
  const updateFitting = (adresKey, aard, fittingKey, val) => {
    const current = werfdata[adresKey] || {};
    const fittings = current.fittings || {};
    const aardFittings = fittings[aard] || {};
    const updated = {
      ...werfdata,
      [adresKey]: {
        ...current,
        fittings: { ...fittings, [aard]: { ...aardFittings, [fittingKey]: val } },
      },
    };
    setData({ ...data, werfdata: updated });
  };

  const addresses = Object.entries(grouped);

  if (addresses.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400 border-2 border-dashed rounded-xl">
        <p className="text-lg mb-1">Eerst adressen invullen in stap 2</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-sm text-green-800">
        <strong>Werfdata per aansluiting — VLARIO Fiche velden (geel)</strong>
        <p className="mt-1 text-green-600">Per adres: positie t.o.v. putten, ligging HA-putje, fittingen (bochten/stops/reducties), meters buis PVC Ø160. Alles nodig voor facturatie.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="md:col-span-1 space-y-1 max-h-96 overflow-y-auto pr-2">
          {addresses.map(([key, grp]) => {
            const wd = werfdata[key] || {};
            const complete = wd.putStroomaf && wd.putStroomop && wd.afstandPut;
            return (
              <button
                key={key}
                onClick={() => setSelected(key)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all border ${
                  selected === key
                    ? "bg-blue-600 text-white border-blue-600"
                    : complete
                    ? "bg-green-50 border-green-200 hover:bg-green-100"
                    : "bg-white border-gray-200 hover:bg-gray-50"
                }`}
              >
                <div className="font-medium">{grp.straat || "?"} {grp.huisnr}</div>
                <div className="text-xs opacity-70 flex gap-1 mt-0.5">
                  {grp.items.map((i) => (
                    <Badge key={i.id} color={i.aard === "DWA" ? "orange" : i.aard === "RWA" ? "blue" : "green"}>
                      {i.aard}
                    </Badge>
                  ))}
                  {complete && <Badge color="green">✓</Badge>}
                </div>
              </button>
            );
          })}
        </div>

        <div className="md:col-span-2">
          {selected && grouped[selected] ? (
            <div className="space-y-4 bg-white rounded-xl border border-gray-200 p-4">
              <h4 className="font-semibold text-gray-800">{grouped[selected].straat} {grouped[selected].huisnr}</h4>

              <div className="bg-gray-50 rounded-lg p-3 space-y-3">
                <h5 className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Positie t.o.v. riool</h5>
                <div className="grid grid-cols-2 gap-3">
                  <FieldGroup label="Put stroomafwaarts (nr)" required>
                    <Input value={(werfdata[selected] || {}).putStroomaf || ""} onChange={(e) => updateWerf(selected, "putStroomaf", e.target.value)} placeholder="bv. P12" />
                  </FieldGroup>
                  <FieldGroup label="Put stroomopwaarts (nr)" required>
                    <Input value={(werfdata[selected] || {}).putStroomop || ""} onChange={(e) => updateWerf(selected, "putStroomop", e.target.value)} placeholder="bv. P13" />
                  </FieldGroup>
                  <FieldGroup label="Afstand tot stroomafwaartse put (m)" required help="Midden put tot mof aansluiting">
                    <Input type="number" step="0.01" value={(werfdata[selected] || {}).afstandPut || ""} onChange={(e) => updateWerf(selected, "afstandPut", e.target.value)} placeholder="bv. 12.50" />
                  </FieldGroup>
                  <FieldGroup label="Ligging HA-putje" required>
                    <Select options={LIGGING_OPTIONS} value={(werfdata[selected] || {}).ligging || ""} onChange={(v) => updateWerf(selected, "ligging", v)} />
                  </FieldGroup>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <FieldGroup label="Afstand tot rechtergevel (m)" required help="Horizontaal, vanuit perceelsgrens">
                    <Input type="number" step="0.01" value={(werfdata[selected] || {}).afstandGevel || ""} onChange={(e) => updateWerf(selected, "afstandGevel", e.target.value)} placeholder="bv. 3.20" />
                  </FieldGroup>
                  <FieldGroup label="Afstand tot rooilijn (m)" required help="Loodrecht op rooilijn">
                    <Input type="number" step="0.01" value={(werfdata[selected] || {}).afstandRooilijn || ""} onChange={(e) => updateWerf(selected, "afstandRooilijn", e.target.value)} placeholder="bv. 1.50" />
                  </FieldGroup>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <FieldGroup label="Diepte HA-putje t.o.v. MV (m)">
                    <Input type="number" step="0.01" value={(werfdata[selected] || {}).diepteHA || ""} onChange={(e) => updateWerf(selected, "diepteHA", e.target.value)} placeholder="bv. 0.80" />
                  </FieldGroup>
                  <FieldGroup label="Hoek aansluiting op riool">
                    <Select options={HOEK_OPTIONS} value={(werfdata[selected] || {}).hoek || ""} onChange={(v) => updateWerf(selected, "hoek", v)} />
                  </FieldGroup>
                </div>
                <FieldGroup label="Type aansluiting op hoofdriool">
                  <Select options={TYPE_AANSLUITING} value={(werfdata[selected] || {}).typeAansluiting || ""} onChange={(v) => updateWerf(selected, "typeAansluiting", v)} />
                </FieldGroup>
              </div>

              {grouped[selected].items.filter((i) => i.aard === "DWA" || i.aard === "RWA" || i.aard === "GEM").map((item) => (
                <div key={item.id} className={`rounded-lg p-3 space-y-3 ${item.aard === "DWA" ? "bg-orange-50" : item.aard === "RWA" ? "bg-blue-50" : "bg-green-50"}`}>
                  <h5 className="text-xs font-semibold uppercase tracking-wide flex items-center gap-2">
                    <Badge color={item.aard === "DWA" ? "orange" : item.aard === "RWA" ? "blue" : "green"}>{item.aard}</Badge>
                    Hoeveelheden — Ø{item.diameter}mm {item.materiaal}
                  </h5>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    <FieldGroup label="Meters buis (m)" required>
                      <Input
                        type="number" step="0.01"
                        value={((werfdata[selected] || {}).fittings || {})[item.aard]?.buis_m || ""}
                        onChange={(e) => updateFitting(selected, item.aard, "buis_m", e.target.value)}
                        placeholder="0.00"
                      />
                    </FieldGroup>
                    {FITTING_TYPES.map((f) => (
                      <FieldGroup key={f.key} label={`${f.icon} ${f.label}`}>
                        <Input
                          type="number" min="0"
                          value={((werfdata[selected] || {}).fittings || {})[item.aard]?.[f.key] || ""}
                          onChange={(e) => updateFitting(selected, item.aard, f.key, e.target.value)}
                          placeholder="0"
                        />
                      </FieldGroup>
                    ))}
                  </div>
                  <FieldGroup label="HA-putje diameter (mm)">
                    <Select
                      options={["315", "400", "500", "NVT"]}
                      value={((werfdata[selected] || {}).fittings || {})[item.aard]?.ha_putje_diam || ""}
                      onChange={(v) => updateFitting(selected, item.aard, "ha_putje_diam", v)}
                    />
                  </FieldGroup>
                  <FieldGroup label="Terugslagklep in HA-putje">
                    <Select
                      options={["ja", "nee"]}
                      value={((werfdata[selected] || {}).fittings || {})[item.aard]?.terugslagklep || ""}
                      onChange={(v) => updateFitting(selected, item.aard, "terugslagklep", v)}
                    />
                  </FieldGroup>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400 text-sm">
              ← Selecteer een adres om werfdata in te vullen
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StepFotos({ data }) {
  const aansluitingen = data.aansluitingen || [];
  const uniqueAddresses = [...new Set(aansluitingen.map((a) => `${a.straat} ${a.huisnr}`))].filter((a) => a.trim());

  return (
    <div className="space-y-4">
      <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-sm text-purple-800">
        <strong>VLARIO SB250 v4.1 — Foto-vereisten per aansluiting</strong>
        <p className="mt-1 text-purple-600">4 foto's per DWA/GEM + 4 foto's per RWA. Gebruik het knipprogramma van Windows of maak foto's met smartphone en verklein ze (max enkele KB per foto).</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {FOTO_SPECS.map((spec) => (
          <div key={spec.id} className="bg-white rounded-xl border border-gray-200 p-4 space-y-2">
            <div className="flex items-start justify-between">
              <Badge color="purple">Foto {spec.id}</Badge>
              <span className="text-xs text-gray-400">{spec.timing}</span>
            </div>
            <h4 className="font-semibold text-gray-800 text-sm">{spec.title}</h4>
            <p className="text-xs text-gray-500">{spec.desc}</p>
            <div className="w-full h-24 border-2 border-dashed border-gray-200 rounded-lg flex items-center justify-center text-gray-300 text-xs">
              📷 Foto hier invoegen op werf
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gray-50 rounded-xl p-4 space-y-3 border border-gray-200">
        <h4 className="font-semibold text-gray-700 text-sm">Workflow op werf</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-600">
          <div className="space-y-2">
            <p className="font-medium text-gray-700">Optie A: Smartphone</p>
            <p>1. Neem foto's met telefoon tijdens aanleg</p>
            <p>2. Benaam foto's: <code className="bg-gray-200 px-1 rounded text-xs">[straat]_[nr]_[DWA/RWA]_foto[1-4].jpg</code></p>
            <p>3. Verklein tot max 200KB via app</p>
            <p>4. Upload naar gedeelde map per fase</p>
          </div>
          <div className="space-y-2">
            <p className="font-medium text-gray-700">Optie B: Tablet op werf</p>
            <p>1. Open werfformulier op tablet</p>
            <p>2. Neem foto direct vanuit het formulier</p>
            <p>3. Automatische naamgeving & compressie</p>
            <p>4. Sync bij wifi-verbinding</p>
          </div>
        </div>
      </div>

      {uniqueAddresses.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-gray-700 text-sm">Status per adres ({uniqueAddresses.length} adressen)</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {uniqueAddresses.map((addr) => (
              <div key={addr} className="bg-white border border-gray-200 rounded-lg p-2 text-xs">
                <span className="font-medium">{addr}</span>
                <div className="flex gap-1 mt-1">
                  <Badge color="gray">0/4 DWA</Badge>
                  <Badge color="gray">0/4 RWA</Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StepCoordinaten() {
  return (
    <div className="space-y-4">
      <div className="bg-teal-50 border border-teal-200 rounded-xl p-4 text-sm text-teal-800">
        <strong>Lambert72 X/Y/Z (TAW) coördinaten per HA-putje deksel</strong>
        <p className="mt-1 text-teal-600">Vereist op het einde van het project in de overzichtslijst. Twee methoden beschikbaar.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {GPS_METHODS.map((method) => (
          <div key={method.id} className="bg-white rounded-xl border border-gray-200 p-5 space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{method.icon}</span>
              <div>
                <h4 className="font-semibold text-gray-800">{method.name}</h4>
                <Badge color={method.id === "topcon" ? "green" : "amber"}>{method.accuracy}</Badge>
              </div>
            </div>
            <p className="text-sm text-gray-600">{method.desc}</p>
            <ol className="space-y-1.5">
              {method.workflow.map((step, i) => (
                <li key={i} className="text-sm text-gray-600 flex gap-2">
                  <span className="text-xs bg-gray-100 rounded-full w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5 font-medium">{i + 1}</span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
        ))}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        <strong>Export formaat voor VLARIO template:</strong>
        <p className="mt-1 font-mono text-xs">Equipmentnr | X (Lambert72) | Y (Lambert72) | Z (TAW m)</p>
        <p className="mt-1 font-mono text-xs">123456789 | 151234.56 | 203456.78 | 5.432</p>
      </div>
    </div>
  );
}

function StepFacturatie({ data }) {
  const aansluitingen = data.aansluitingen || [];
  const werfdata = data.werfdata || {};

  const grouped = {};
  aansluitingen.forEach((a) => {
    const key = `${a.straat || "?"}_${a.huisnr || "?"}`;
    if (!grouped[key]) grouped[key] = { straat: a.straat, huisnr: a.huisnr, items: [] };
    grouped[key].items.push(a);
  });

  const totals = {};
  Object.entries(grouped).forEach(([key, grp]) => {
    const wd = werfdata[key] || {};
    const fittings = wd.fittings || {};
    grp.items.forEach((item) => {
      const af = fittings[item.aard] || {};
      Object.entries(af).forEach(([fk, fv]) => {
        const num = parseFloat(fv) || 0;
        if (num > 0) {
          if (!totals[fk]) totals[fk] = 0;
          totals[fk] += num;
        }
      });
    });
  });

  return (
    <div className="space-y-4">
      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-sm text-emerald-800">
        <strong>Facturatie-overzicht — Automatisch berekend uit werfdata</strong>
        <p className="mt-1 text-emerald-600">Totale hoeveelheden per materiaaltype voor vorderingsstaat. Wordt gegenereerd uit stap 3 data.</p>
      </div>

      {Object.keys(totals).length === 0 ? (
        <div className="text-center py-12 text-gray-400 border-2 border-dashed rounded-xl">
          <p className="text-lg mb-1">Nog geen hoeveelheden ingevoerd</p>
          <p className="text-sm">Vul eerst werfdata in bij stap 3</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Totale hoeveelheden</h4>
            <div className="space-y-2">
              {Object.entries(totals).map(([key, val]) => {
                const fitting = FITTING_TYPES.find((f) => f.key === key);
                const label = fitting ? fitting.label : key === "buis_m" ? "Buis (m)" : key === "ha_putje_diam" ? "HA-putje" : key;
                const unit = key === "buis_m" ? "m" : fitting ? "st" : "";
                return (
                  <div key={key} className="flex justify-between items-center py-1 border-b border-gray-100">
                    <span className="text-sm text-gray-600">{label}</span>
                    <span className="font-mono font-semibold text-gray-800">{val} {unit}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h4 className="font-semibold text-gray-800 mb-3 text-sm">Per adres</h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {Object.entries(grouped).map(([key, grp]) => {
                const wd = werfdata[key] || {};
                const fittings = wd.fittings || {};
                const totalBuis = Object.values(fittings).reduce((s, af) => s + (parseFloat(af?.buis_m) || 0), 0);
                return (
                  <div key={key} className="flex justify-between items-center py-1 border-b border-gray-100">
                    <span className="text-sm text-gray-600">{grp.straat} {grp.huisnr}</span>
                    <span className="font-mono text-xs text-gray-500">{totalBuis > 0 ? `${totalBuis}m buis` : "—"}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StepExport({ data }) {
  return (
    <div className="space-y-4">
      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 text-sm text-indigo-800">
        <strong>Generatie VLARIO-conforme output</strong>
        <p className="mt-1 text-indigo-600">De verzamelde data wordt geëxporteerd naar het VLARIO .xlsm template formaat, klaar voor macro-uitrol van individuele fiches + PDF export.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-2">
          <div className="text-2xl">📊</div>
          <h4 className="font-semibold text-gray-800 text-sm">1. Excel Generatie</h4>
          <p className="text-xs text-gray-500">Vult automatisch alle tabbladen in het VLARIO .xlsm template: Algemene gegevens, Project HA, Project WA, Project kolk + alle hoeveelheden per fiche.</p>
          <Badge color="blue">Tabblad "Algemene gegevens"</Badge>
          <Badge color="amber">Tabblad "Project HA/WA/kolk"</Badge>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-2">
          <div className="text-2xl">📝</div>
          <h4 className="font-semibold text-gray-800 text-sm">2. Macro uitvoeren</h4>
          <p className="text-xs text-gray-500">Na invulling overzichtslijsten: macro draaien per tabblad (HA/WA/kolk) om individuele fiches aan te maken. Eenmalig per overzichtslijst.</p>
          <Badge color="orange">Macro 1x per tabblad</Badge>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-2">
          <div className="text-2xl">📄</div>
          <h4 className="font-semibold text-gray-800 text-sm">3. PDF Export</h4>
          <p className="text-xs text-gray-500">Via "Print naar PDF" macro: genereert 1 PDF per adres/fiche met correcte bestandsnaam. Inclusief foto's en situatieschets.</p>
          <Badge color="green">1 PDF per fiche</Badge>
        </div>
      </div>

      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <h4 className="font-semibold text-gray-700 text-sm mb-3">Bestandsnaamconventie (automatisch)</h4>
        <div className="space-y-1 font-mono text-xs text-gray-600">
          <p>GEM=[gemeentecode] projectnr=[nr] adres=[straat] [nr] eq=[equipmentnr] AB-HA-fiche</p>
          <p className="text-gray-400">Voorbeeld: GEM=ZWI projectnr=23.456 adres=Burchtsestraat 12 eq=123456789 AB-HA-fiche</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
        <h4 className="font-semibold text-gray-700 text-sm">Samenvatting ingevoerde data</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="text-2xl font-bold text-gray-800">{(data.aansluitingen || []).length}</div>
            <div className="text-xs text-gray-500">Totaal rijen</div>
          </div>
          <div className="bg-orange-50 rounded-lg p-3">
            <div className="text-2xl font-bold text-orange-800">{(data.aansluitingen || []).filter((a) => a.aard === "DWA").length}</div>
            <div className="text-xs text-gray-500">DWA aansluitingen</div>
          </div>
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="text-2xl font-bold text-blue-800">{(data.aansluitingen || []).filter((a) => a.aard === "RWA").length}</div>
            <div className="text-xs text-gray-500">RWA aansluitingen</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <div className="text-2xl font-bold text-green-800">{(data.aansluitingen || []).filter((a) => a.soort === "kolk").length}</div>
            <div className="text-xs text-gray-500">Kolken</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function VLARIOWorkflow() {
  const [currentStep, setCurrentStep] = useState(0);
  const [data, setData] = useState({
    aannemer: "Colas Belgium",
    aansluitingen: [],
    werfdata: {},
  });

  const stepComponents = [
    <StepProjectgegevens data={data} setData={setData} />,
    <StepAdressen data={data} setData={setData} />,
    <StepWerfdata data={data} setData={setData} />,
    <StepFotos data={data} />,
    <StepCoordinaten />,
    <StepFacturatie data={data} />,
    <StepExport data={data} />,
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-blue-50" style={{ fontFamily: "'Segoe UI', -apple-system, sans-serif" }}>
      <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-4">
        {/* Header */}
        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-md">V</div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">VLARIO Huisaansluitfiches</h1>
                  <p className="text-xs text-gray-400">Workflow Data Gathering — DWA / RWA / Kolk</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <Badge color="blue">Colas Belgium</Badge>
              <span>Puurs • Zwijndrecht</span>
            </div>
          </div>
        </div>

        {/* Step Navigation */}
        <div className="overflow-x-auto">
          <div className="flex gap-1 min-w-max">
            {STEPS.map((step, i) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(i)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all whitespace-nowrap ${
                  i === currentStep
                    ? "bg-blue-600 text-white shadow-md shadow-blue-200"
                    : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
                }`}
              >
                <span>{step.icon}</span>
                <span className="font-medium hidden md:inline">{step.title}</span>
                <span className="font-medium md:hidden">{i + 1}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm min-h-96">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-gray-800">{STEPS[currentStep].title}</h2>
            <p className="text-sm text-gray-400">{STEPS[currentStep].desc}</p>
          </div>
          {stepComponents[currentStep]}
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="px-5 py-2.5 bg-white border border-gray-200 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-50 disabled:opacity-40 transition-all"
          >
            ← Vorige
          </button>
          <button
            onClick={() => setCurrentStep(Math.min(STEPS.length - 1, currentStep + 1))}
            disabled={currentStep === STEPS.length - 1}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 disabled:opacity-40 shadow-md shadow-blue-200 transition-all"
          >
            Volgende →
          </button>
        </div>
      </div>
    </div>
  );
}
