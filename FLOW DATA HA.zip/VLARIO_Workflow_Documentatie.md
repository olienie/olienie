# VLARIO Huisaansluitfiches — Volledige Data Gathering Workflow
## Colas Belgium | Puurs & Zwijndrecht | Gescheiden Riolering

---

## OVERZICHT WORKFLOW

Deze workflow beschrijft het volledige proces voor het verzamelen van alle data die nodig is om VLARIO-conforme huisaansluitfiches te genereren voor **DWA (droogweerafvoer)**, **RWA (regenwaterafvoer)** en **kolkaansluitingen** bij aanleg van nieuwe gescheiden riolering.

### Doel
- Alle info verzamelen voor correcte facturatie (materialen + hoeveelheden)
- VLARIO-conforme as-built fiches genereren per aansluiting
- Data gestructureerd inzamelen op de werf (manueel of GPS)
- Automatisch invullen van het VLARIO .xlsm template

### Scope
- **Puurs**: 3 fases gescheiden riolering + 2 pompstations (werfleider: Olivier)
- **Zwijndrecht**: 7 fases (Burchtsestraat → Verbrandendijk) (werfleider: Junior, niet fulltime)

---

## STAP 1: PROJECTGEGEVENS

**Bron:** Rioolbeheerder levert bij aanvang project → VLARIO tabblad "Algemene gegevens"

### Velden (blauw = rioolbeheerder / geel = aannemer)

| Veld | Ingevuld door | Voorbeeld |
|---|---|---|
| Naam rioolbeheerder | Rioolbeheerder | Aquafin / Fluvius / Pidpa |
| Projectnummer rioolbeheerder | Rioolbeheerder | 23.456 |
| Projectnaam | Rioolbeheerder | Gescheiden riolering Burchtsestraat |
| Gemeente | Rioolbeheerder | Zwijndrecht |
| Gemeentecode | Rioolbeheerder | ZWI |
| Naam bouwheer | Rioolbeheerder | Gemeente Zwijndrecht |
| Naam aannemer | Aannemer | Colas Belgium |
| Projectnummer aannemer | Aannemer | [intern nr] |
| Werfleider | Aannemer | Olivier (Puurs) / Junior (Zwijndrecht) |

---

## STAP 2: ADRESSENLIJST OPBOUWEN

**Bron:** Rioolbeheerder + Aannemer → VLARIO tabbladen "Project HA", "Project WA", "Project kolk"

### Regels
- **HA (huisaansluiting)**: Elk bewoond adres krijgt **2 rijen**: 1× DWA + 1× RWA
- **WA (wachtaansluiting)**: Onbebouwde percelen, ook 2 rijen per perceel (DWA + RWA)
- **Kolk**: Straatkolken, **1 rij per kolk** (enkel RWA)
- Bij GEM (gemengd water): DWA vervangen door GEM in de aard-kolom
- Tweede aansluiting zelfde type: equipmentnr + "b" (derde: "c", enz.)

### Velden per rij

| Kolom | Beschrijving | Standaard |
|---|---|---|
| Straat | Straatnaam | - |
| Huisnr / Volgnr | Huisnummer (HA) of volgnummer (WA/kolk) | - |
| Equipmentnummer | Uniek nr van rioolbeheerder | - |
| Aard water | DWA / RWA / GEM | - |
| Soort | HA / WA / kolk | - |
| Diameter (mm) | Bijna altijd **160 mm** | 160 |
| Materiaal | PVC / PP / grès | PVC |

### Naamgeving fiche (automatisch)
```
GEM=[gemeentecode] projectnr=[nr] adres=[straat] [nr] eq=[equipmentnr] AB-HA-fiche
```

---

## STAP 3: WERFDATA INZAMELING (per aansluiting)

**Dit is de kern van de workflow — alles wat op de werf gemeten/geteld moet worden.**

### 3A. Positie t.o.v. rioolstelsel

| Gegeven | Hoe meten | Eenheid |
|---|---|---|
| Put stroomafwaarts (nr) | Aflezen op plantekening | Put ID |
| Put stroomopwaarts (nr) | Aflezen op plantekening | Put ID |
| Afstand midden stroomafwaartse put tot mof | Meetlint langs riool-as | m (2 decimalen) |
| Ligging HA-putje | Visueel: oprit / voortuin / berm / voetpad / fietspad | Keuzelijst |
| Diepte HA-putje t.o.v. MV | Meten vanaf maaiveld tot bovenkant putje | m |
| Diepte aanboring op hoofdriool t.o.v. MV | Enkel bij bestaande riolering! Bij nieuwe riool: leeg laten | m |

### 3B. Situatieschets — Afstanden voor facturatie

**Cruciaal voor facturatie: afstand buis bepaalt meters te factureren!**

| Meting | Beschrijving | Methode |
|---|---|---|
| Afstand tot rechtergevel | Horizontaal vanuit perceelsgrens/gevel tot HA-putje | Meetlint / GPS |
| Afstand tot rooilijn | Loodrecht op de rooilijn tot HA-putje | Meetlint / GPS |
| Positie op tekening markeren | Locatie HA-putje intekenen op grondplan | Pen op plan / tablet |

De VLARIO fiche gebruikt een letterschema (a-f, g-h, m-n, u-z) om de richting van de afstand aan te duiden t.o.v. het perceel. Dit moet correct ingevuld worden.

### 3C. Hoeveelheden per aansluiting (DWA + RWA apart!)

**Alle materialen noteren die gebruikt worden — dit bepaalt de facturatie.**

| Materiaal / Fitting | Eenheid | Typisch voor Ø160 PVC |
|---|---|---|
| **Meters buis PVC Ø160** | m | Variabel per aansluiting |
| Mof | st | Verbinding buizen |
| Bocht 15° | st | Lichte richtingsverandering |
| Bocht 30° | st | - |
| Bocht 45° | st | Meest voorkomend |
| Bocht 90° | st | Haakse bocht |
| Stop | st | Einde buis afsluiten |
| Reductie 110→90 | st | Overgang naar kleiner |
| Reductie 110→130 | st | Overgang naar groter |
| Inlaat / T-stuk | st | Aansluiting op hoofdriool |
| Y-stuk | st | Y-aansluiting |
| Krimpmof | st | Overgang materialen |
| Koppelstuk | st | Verbinding buizen |
| HA-putje diameter | mm | 315 / 400 / 500 |
| Terugslagklep in HA-putje | ja/nee | Afhankelijk van situatie |

### 3D. Type aansluiting op hoofdriool

Keuzelijst: T-buis / T-stuk / Y-stuk / flexibele aansluiting / aanboring

### 3E. Hoek aansluiting

Gezien van stroomafwaarts naar stroomopwaarts: 90° / 135° / 180° / 225° / 270° / NVT

---

## STAP 4: FOTO'S (4 per DWA/GEM + 4 per RWA)

**Volgens VLARIO Standaardbestek 250 versie 4.1**

### Verplichte foto's per aansluittype

| Nr | Beschrijving | Wanneer | Wat moet zichtbaar zijn |
|---|---|---|---|
| **1** | Boring/opening aansluiting op hoofdriool | Bij aanleg | De aanboring of T-stuk op het hoofdriool |
| **2** | Na plaatsing buizen, hulpstukken & HA-putje | Na plaatsing, vóór aanvulling | Volledige aansluiting van opening tot putje, alle hulpstukken zichtbaar |
| **3** | Verbinding HA-putje ↔ privé-riool | Bij koppeling | De aansluiting op de bestaande privé-riolering |
| **4** | Zelfde als foto 2, maar mét omhulling | Na zandbed/omhulling | Zandbed + omhulling zichtbaar, zelfde perspectief als foto 2 |

### Extra bij bestaande riolering
| **5** | Aangevulde sleuf (bij best. riolering) | Na dichtmaken | Enkel nodig bij aansluiting op bestaande riolering |

### Workflow op werf

**Optie A: Smartphone (eenvoudigst)**
1. Foto's maken met telefoon tijdens elke fase
2. Benoemen: `[straat]_[nr]_[DWA/RWA]_foto[1-4].jpg`
3. Verkleinen tot max 200 KB (via app of Windows knipprogramma)
4. Uploaden naar gedeelde map per fase

**Optie B: Tablet met werfformulier**
1. Formulier openen op tablet
2. Foto direct vanuit formulier nemen
3. Automatische naamgeving + compressie
4. Sync bij wifi

**Belangrijk:** Foto's worden NIET ingevoegd in de Excel (te zwaar). Ze worden via knipprogramma of als klein bestand apart bijgehouden en later per fiche in de Excel geplakt.

---

## STAP 5: GPS COÖRDINATEN

**Lambert72 X/Y/Z (TAW) per HA-putje deksel — vereist op einde project**

### Methode 1: Topcon Hyper SR/VR (RTK-GPS) — ±1-2 cm nauwkeurig

1. Start Topcon FC-6000 controller
2. Verbind met FLEPOS netwerk (NTRIP mount: FLEPOS_VRS)
3. Wacht op FIXED oplossing (< 2cm precisie)
4. Meet midden deksel HA-putje
5. Sla punt op met uniek ID = equipmentnummer
6. Exporteer als CSV: X (Lambert72), Y (Lambert72), Z (TAW)

### Methode 2: Manuele opmeting — ±5-10 cm (fallback)

1. Meet afstand vanaf 2 gekende referentiepunten (putten, gevels)
2. Noteer afstand tot stroomafwaartse put (langs as riool)
3. Noteer afstand tot rechtergevel/rooilijn
4. Gebruik plan om Lambert72 coördinaten af te leiden
5. Z-peil: gebruik nivelleringstoestel of bekende putdeksels

### Export formaat
```
Equipmentnr | X (Lambert72) | Y (Lambert72) | Z (TAW m)
123456789   | 151234.56     | 203456.78     | 5.432
```

---

## STAP 6: FACTURATIE-OVERZICHT

Het VLARIO template berekent automatisch de totale hoeveelheden per materiaaltype uit de individuele fiches. De overzichtstabel toont per aansluiting:

- Mof (st)
- Buis (m)
- Bocht (st)
- Y/T-stuk (st)
- Krimpmof (st)
- Koppelstuk (st)
- Reductie (st)
- Stop (st)
- Andere

**Onderaan de overzichtslijst** staat het totaal per kolom, opgesplitst per DWA, RWA en GEM. Dit is de basis voor de vorderingsstaat.

---

## STAP 7: EXPORT & GENERATIE

### Proces
1. **Excel invullen**: Alle data uit stappen 1-5 wordt in het VLARIO .xlsm template gezet
2. **Macro draaien**: Per tabblad (HA/WA/kolk) de macro starten → genereert individuele fiche-tabbladen
3. **Fiches invullen**: Gele velden per fiche invullen (hoeveelheden worden teruggekoppeld naar overzicht)
4. **Foto's toevoegen**: Per fiche de 4 (of 5) foto's invoegen via knipprogramma
5. **PDF exporteren**: Via "Print naar PDF" macro → 1 PDF per fiche met correcte bestandsnaam

### Fasering (aanbevolen door VLARIO)
Lever fiches aan per uitvoeringsfase of per vorderingsstaat. Behoud het standaard template en maak per fase een aangepaste, ingevulde Excel.

### Bestandsnaamconventie
```
GEM=[gemeentecode] projectnr=[nr] adres=[straat] [nr] eq=[equipmentnr] AB-HA-fiche
```

---

## AUTOMATISATIE-MOGELIJKHEDEN

### Wat kan geautomatiseerd worden
1. **Adressenlijst importeren** vanuit GIS/kadaster → automatisch DWA+RWA rijen aanmaken
2. **GPS data importeren** vanuit Topcon CSV → automatisch XYZ coördinaten invullen
3. **Hoeveelheden optellen** → automatisch totalen per materiaal voor vorderingsstaat
4. **PDF generatie** → batch alle fiches naar PDF in correcte mapstructuur
5. **Foto-naamgeving** → automatische conventie op basis van equipmentnr

### Wat manueel blijft
- Feitelijke metingen op werf (afstanden, dieptes)
- Tellen van fittingen per aansluiting
- Foto's nemen op correcte momenten
- Visuele controle situatieschets

---

## CHECKLIST PER AANSLUITING

- [ ] Adres + equipmentnr in overzichtslijst
- [ ] Aard water (DWA/RWA/GEM) correct
- [ ] Diameter + materiaal ingevuld
- [ ] Put stroomaf + stroomop genoteerd
- [ ] Afstand tot stroomafwaartse put gemeten
- [ ] Ligging HA-putje genoteerd
- [ ] Afstand tot gevel + rooilijn gemeten
- [ ] Diepte HA-putje gemeten
- [ ] Type aansluiting op hoofdriool genoteerd
- [ ] Hoek aansluiting genoteerd
- [ ] Alle fittingen geteld (bochten, stops, reducties, enz.)
- [ ] Meters buis gemeten
- [ ] HA-putje diameter + terugslagklep ja/nee
- [ ] Foto 1: boring/opening
- [ ] Foto 2: plaatsing buizen + hulpstukken
- [ ] Foto 3: verbinding privé-riool
- [ ] Foto 4: met omhulling
- [ ] GPS coördinaten Lambert72 XYZ
