#!/usr/bin/env python3
"""
VLARIO Huisaansluitfiches — Automatische Template Vuller
=========================================================
Colas Belgium | Puurs & Zwijndrecht

Dit script leest werfdata uit een Google Sheets export (Excel/CSV) en
GPS-data uit een Topcon CSV export, en vult automatisch het VLARIO .xlsm
template in per fase.

Gebruik:
    python vlario_filler.py --werfdata werfdata.xlsx --gps topcon_export.csv --template vlario_template.xlsm --output output_fase1.xlsm

Of zonder GPS:
    python vlario_filler.py --werfdata werfdata.xlsx --template vlario_template.xlsm --output output_fase1.xlsm
"""

import argparse
import csv
import os
import sys
from copy import copy
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


# =============================================================================
# CONFIGURATIE
# =============================================================================

# Kolom-mapping Google Form → intern
FORM_COLUMNS = {
    "tijdstempel": "Tijdstempel",
    "werf": "Werf (Puurs/Zwijndrecht)",
    "fase": "Fase",
    "straat": "Straatnaam",
    "huisnr": "Huisnummer",
    "equipmentnr": "Equipmentnummer",
    "aard": "Aard water (DWA/RWA/GEM)",
    "soort": "Soort (HA/WA/kolk)",
    "diameter": "Diameter (mm)",
    "materiaal": "Materiaal (PVC/PP/grès)",
    "put_stroomaf": "Put stroomafwaarts (nr)",
    "put_stroomop": "Put stroomopwaarts (nr)",
    "afstand_put": "Afstand tot stroomafwaartse put (m)",
    "ligging": "Ligging HA-putje",
    "diepte_ha": "Diepte HA-putje tov MV (m)",
    "diepte_aanboring": "Diepte aanboring op hoofdriool tov MV (m)",
    "type_aansluiting": "Type aansluiting op hoofdriool",
    "hoek": "Hoek aansluiting (graden)",
    "mof": "Mof (st)",
    "buis_m": "Buis (m)",
    "bocht": "Bocht (st)",
    "y_stuk": "Y/T-stuk (st)",
    "krimpmof": "Krimpmof (st)",
    "koppelstuk": "Koppelstuk (st)",
    "reductie": "Reductie (st)",
    "stop": "Stop (st)",
    "andere": "Andere",
    "ha_putje_diam": "HA-putje diameter (mm)",
    "terugslagklep": "Terugslagklep (ja/nee)",
    "afstand_h_letter": "Afstand putje horizontaal (letter)",
    "afstand_h_m": "Afstand putje horizontaal (m)",
    "afstand_v_letter": "Afstand putje vertikaal (letter)",
    "afstand_v_m": "Afstand putje vertikaal (m)",
    "rwa_infiltratie": "RWA infiltratieputje (ja/nee)",
    "rwa_opengracht": "RWA aansluiting op opengracht (ja/nee)",
    "kolk_infiltratieklok": "Kolk infiltratieklok (ja/nee)",
    "kolk_opengracht": "Kolk aansluiting op opengracht (ja/nee)",
}

# Projectgegevens — pas aan per project
PROJECT_DEFAULTS = {
    "Puurs": {
        "rioolbeheerder": "",  # In te vullen
        "projectnr_rb": "",
        "projectnaam": "Gescheiden riolering Puurs",
        "gemeente": "Puurs-Sint-Amands",
        "gemeentecode": "PUU",
        "bouwheer": "",
        "aannemer": "Colas Belgium",
        "projectnr_an": "",
        "werfleider": "Olivier",
    },
    "Zwijndrecht": {
        "rioolbeheerder": "",
        "projectnr_rb": "",
        "projectnaam": "Gescheiden riolering Zwijndrecht",
        "gemeente": "Zwijndrecht",
        "gemeentecode": "ZWI",
        "bouwheer": "",
        "aannemer": "Colas Belgium",
        "projectnr_an": "",
        "werfleider": "Junior",
    },
}


# =============================================================================
# DATA INLEZEN
# =============================================================================

def lees_werfdata(pad):
    """Leest Google Sheets export (xlsx of csv) en retourneert lijst van dicts."""
    ext = os.path.splitext(pad)[1].lower()

    if ext in (".xlsx", ".xls"):
        return _lees_xlsx(pad)
    elif ext == ".csv":
        return _lees_csv(pad)
    else:
        print(f"[FOUT] Onbekend bestandstype: {ext}")
        sys.exit(1)


def _lees_xlsx(pad):
    """Leest xlsx bestand (Google Sheets download)."""
    wb = openpyxl.load_workbook(pad, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [str(h).strip() if h else "" for h in rows[0]]
    data = []
    for row in rows[1:]:
        if not any(row):
            continue
        record = {}
        for i, val in enumerate(row):
            if i < len(headers) and headers[i]:
                record[headers[i]] = val if val is not None else ""
        data.append(record)
    return data


def _lees_csv(pad):
    """Leest CSV bestand."""
    data = []
    with open(pad, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=",")
        for row in reader:
            data.append({k.strip(): v.strip() for k, v in row.items() if k is not None})
    # Probeer ook ; als delimiter
    if not data or len(data[0]) <= 1:
        data = []
        with open(pad, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f, delimiter=";")
            for row in reader:
                data.append({k.strip(): v.strip() for k, v in row.items() if k is not None})
    return data


def lees_gps_csv(pad):
    """
    Leest Topcon GPS export CSV.
    Verwacht kolommen: PuntID/Equipmentnr, X, Y, Z
    Retourneert dict: {equipmentnr: (x, y, z)}
    """
    gps = {}
    data = _lees_csv(pad)
    if not data:
        return gps

    headers = list(data[0].keys())
    # Auto-detect kolommen
    id_col = None
    x_col = None
    y_col = None
    z_col = None
    for h in headers:
        hl = h.lower()
        if any(k in hl for k in ["punt", "id", "equip", "name", "naam"]):
            id_col = h
        elif "x" in hl and not x_col:
            x_col = h
        elif "y" in hl and not y_col:
            y_col = h
        elif "z" in hl or "hoogte" in hl or "height" in hl:
            z_col = h

    if not all([id_col, x_col, y_col]):
        print(f"[WAARSCHUWING] GPS CSV kolommen niet herkend. Headers: {headers}")
        print(f"  Verwacht: kolom met 'punt/id/equip' + 'x' + 'y' + 'z'")
        return gps

    for row in data:
        punt_id = str(row.get(id_col, "")).strip()
        if not punt_id:
            continue
        try:
            x = float(str(row.get(x_col, "")).replace(",", "."))
            y = float(str(row.get(y_col, "")).replace(",", "."))
            z = float(str(row.get(z_col, "0")).replace(",", ".")) if z_col else 0.0
            gps[punt_id] = (x, y, z)
        except (ValueError, TypeError):
            pass

    print(f"[INFO] {len(gps)} GPS-punten ingelezen uit {pad}")
    return gps


# =============================================================================
# KOLOM-MAPPING HELPER
# =============================================================================

def zoek_kolom(record, intern_key):
    """Zoekt een waarde in het record via de FORM_COLUMNS mapping."""
    form_naam = FORM_COLUMNS.get(intern_key, intern_key)
    # Probeer exacte match
    if form_naam in record:
        return record[form_naam]
    # Probeer case-insensitive
    for k, v in record.items():
        if k.lower().strip() == form_naam.lower().strip():
            return v
    # Probeer intern_key direct
    if intern_key in record:
        return record[intern_key]
    return ""


def safe_float(val, default=0.0):
    """Converteer naar float, return default bij fout."""
    if val is None or val == "":
        return default
    try:
        return float(str(val).replace(",", "."))
    except (ValueError, TypeError):
        return default


def safe_int(val, default=0):
    """Converteer naar int."""
    f = safe_float(val, default)
    return int(f)


# =============================================================================
# VLARIO TEMPLATE VULLEN
# =============================================================================

def vul_algemene_gegevens(ws, project_info):
    """Vult tabblad 'Algemene gegevens' in."""
    ws["B4"] = project_info.get("rioolbeheerder", "")
    ws["B5"] = project_info.get("projectnr_rb", "")
    ws["B6"] = project_info.get("projectnaam", "")
    ws["B7"] = project_info.get("gemeente", "")
    ws["F7"] = project_info.get("gemeentecode", "")
    ws["B10"] = project_info.get("bouwheer", "")
    ws["B11"] = project_info.get("projectnr_bh", "")
    ws["B20"] = project_info.get("projectnr_an", "")
    ws["B21"] = project_info.get("aannemer", "Colas Belgium")
    ws["B22"] = project_info.get("werfleider", "")


def vul_project_ha(ws, records, gps_data):
    """
    Vult tabblad 'Project HA' in.
    Filtert op soort=HA en soort=WA (WA gaat naar apart tabblad).
    """
    ha_records = [r for r in records if zoek_kolom(r, "soort").upper() in ("HA", "")]
    if not ha_records:
        return 0

    # Sorteer: per adres, DWA eerst dan RWA
    def sort_key(r):
        straat = str(zoek_kolom(r, "straat"))
        nr = str(zoek_kolom(r, "huisnr"))
        aard = zoek_kolom(r, "aard").upper()
        aard_order = 0 if aard == "DWA" else (1 if aard == "RWA" else 2)
        return (straat, nr, aard_order)

    ha_records.sort(key=sort_key)

    start_row = 5  # Eerste data-rij in template
    for i, rec in enumerate(ha_records):
        row = start_row + i
        eq = str(zoek_kolom(rec, "equipmentnr"))

        ws.cell(row=row, column=1).value = zoek_kolom(rec, "straat")       # A: Straat
        ws.cell(row=row, column=2).value = zoek_kolom(rec, "huisnr")       # B: Huisnr
        ws.cell(row=row, column=3).value = eq                               # C: Equipmentnr
        ws.cell(row=row, column=4).value = zoek_kolom(rec, "aard")         # D: Aard water
        ws.cell(row=row, column=5).value = "HA"                             # E: Soort
        ws.cell(row=row, column=6).value = safe_int(zoek_kolom(rec, "diameter"), 160)  # F: Diameter
        ws.cell(row=row, column=7).value = zoek_kolom(rec, "materiaal") or "PVC"       # G: Materiaal

        # GPS coördinaten
        if eq in gps_data:
            x, y, z = gps_data[eq]
            ws.cell(row=row, column=8).value = x   # H: X
            ws.cell(row=row, column=9).value = y   # I: Y
            ws.cell(row=row, column=10).value = z  # J: Z

        # Hoeveelheden
        ws.cell(row=row, column=11).value = safe_int(zoek_kolom(rec, "mof"))        # K: Mof
        ws.cell(row=row, column=12).value = safe_float(zoek_kolom(rec, "buis_m"))   # L: Buis (m)
        ws.cell(row=row, column=13).value = safe_int(zoek_kolom(rec, "bocht"))      # M: Bocht
        ws.cell(row=row, column=14).value = safe_int(zoek_kolom(rec, "y_stuk"))     # N: Y/T-stuk
        ws.cell(row=row, column=15).value = safe_int(zoek_kolom(rec, "krimpmof"))   # O: Krimpmof
        ws.cell(row=row, column=16).value = safe_int(zoek_kolom(rec, "koppelstuk")) # P: Koppelstuk
        ws.cell(row=row, column=17).value = safe_int(zoek_kolom(rec, "reductie"))   # Q: Reductie
        ws.cell(row=row, column=18).value = safe_int(zoek_kolom(rec, "stop"))       # R: Stop
        ws.cell(row=row, column=19).value = zoek_kolom(rec, "andere")               # S: Andere
        ws.cell(row=row, column=20).value = safe_int(zoek_kolom(rec, "ha_putje_diam"))  # T: HA-putje Ø
        ws.cell(row=row, column=21).value = zoek_kolom(rec, "terugslagklep")        # U: Terugslagklep

    print(f"  [Project HA] {len(ha_records)} rijen ingevuld (rij {start_row}-{start_row + len(ha_records) - 1})")
    return len(ha_records)


def vul_project_wa(ws, records, gps_data):
    """Vult tabblad 'Project WA' in voor wachtaansluitingen."""
    wa_records = [r for r in records if zoek_kolom(r, "soort").upper() == "WA"]
    if not wa_records:
        return 0

    start_row = 7  # WA template start op rij 7
    for i, rec in enumerate(wa_records):
        row = start_row + i
        eq = str(zoek_kolom(rec, "equipmentnr"))

        ws.cell(row=row, column=1).value = zoek_kolom(rec, "straat")
        ws.cell(row=row, column=2).value = zoek_kolom(rec, "huisnr")
        ws.cell(row=row, column=3).value = eq
        ws.cell(row=row, column=4).value = zoek_kolom(rec, "aard")
        ws.cell(row=row, column=5).value = "WA"
        ws.cell(row=row, column=6).value = safe_int(zoek_kolom(rec, "diameter"), 160)
        ws.cell(row=row, column=7).value = zoek_kolom(rec, "materiaal") or "PVC"

        if eq in gps_data:
            x, y, z = gps_data[eq]
            ws.cell(row=row, column=8).value = x
            ws.cell(row=row, column=9).value = y
            ws.cell(row=row, column=10).value = z

        ws.cell(row=row, column=11).value = safe_int(zoek_kolom(rec, "mof"))
        ws.cell(row=row, column=12).value = safe_float(zoek_kolom(rec, "buis_m"))
        ws.cell(row=row, column=13).value = safe_int(zoek_kolom(rec, "bocht"))
        ws.cell(row=row, column=14).value = safe_int(zoek_kolom(rec, "y_stuk"))
        ws.cell(row=row, column=15).value = safe_int(zoek_kolom(rec, "krimpmof"))
        ws.cell(row=row, column=16).value = safe_int(zoek_kolom(rec, "koppelstuk"))
        ws.cell(row=row, column=17).value = safe_int(zoek_kolom(rec, "reductie"))
        ws.cell(row=row, column=18).value = safe_int(zoek_kolom(rec, "stop"))
        ws.cell(row=row, column=19).value = zoek_kolom(rec, "andere")
        ws.cell(row=row, column=20).value = safe_int(zoek_kolom(rec, "ha_putje_diam"))
        ws.cell(row=row, column=21).value = zoek_kolom(rec, "terugslagklep")

    print(f"  [Project WA] {len(wa_records)} rijen ingevuld")
    return len(wa_records)


def vul_project_kolk(ws, records):
    """Vult tabblad 'Project kolk' in."""
    kolk_records = [r for r in records if zoek_kolom(r, "soort").upper() == "KOLK"]
    if not kolk_records:
        return 0

    start_row = 7
    for i, rec in enumerate(kolk_records):
        row = start_row + i
        ws.cell(row=row, column=1).value = zoek_kolom(rec, "straat")
        ws.cell(row=row, column=2).value = zoek_kolom(rec, "huisnr")
        ws.cell(row=row, column=3).value = str(zoek_kolom(rec, "equipmentnr"))
        ws.cell(row=row, column=4).value = "RWA"
        ws.cell(row=row, column=5).value = "kolk"
        ws.cell(row=row, column=6).value = safe_int(zoek_kolom(rec, "diameter"), 160)
        ws.cell(row=row, column=7).value = zoek_kolom(rec, "materiaal") or "PVC"

        ws.cell(row=row, column=8).value = safe_int(zoek_kolom(rec, "mof"))
        ws.cell(row=row, column=9).value = safe_float(zoek_kolom(rec, "buis_m"))
        ws.cell(row=row, column=10).value = safe_int(zoek_kolom(rec, "bocht"))
        ws.cell(row=row, column=11).value = safe_int(zoek_kolom(rec, "y_stuk"))
        ws.cell(row=row, column=12).value = safe_int(zoek_kolom(rec, "krimpmof"))
        ws.cell(row=row, column=13).value = safe_int(zoek_kolom(rec, "koppelstuk"))
        ws.cell(row=row, column=14).value = safe_int(zoek_kolom(rec, "reductie"))
        ws.cell(row=row, column=15).value = safe_int(zoek_kolom(rec, "stop"))
        ws.cell(row=row, column=16).value = zoek_kolom(rec, "andere")

    print(f"  [Project kolk] {len(kolk_records)} rijen ingevuld")
    return len(kolk_records)


# =============================================================================
# VALIDATIE
# =============================================================================

def valideer_data(records):
    """Valideert de werfdata en print waarschuwingen."""
    fouten = []
    waarschuwingen = []

    for i, rec in enumerate(records):
        rij = i + 2  # +2 voor header + 0-index
        straat = zoek_kolom(rec, "straat")
        huisnr = zoek_kolom(rec, "huisnr")
        adres = f"{straat} {huisnr}" if straat else f"rij {rij}"

        # Blokkerende fouten
        if not straat:
            fouten.append(f"  ❌ Rij {rij}: Geen straatnaam")
        if not zoek_kolom(rec, "equipmentnr"):
            fouten.append(f"  ❌ {adres}: Geen equipmentnummer")
        if not zoek_kolom(rec, "aard"):
            fouten.append(f"  ❌ {adres}: Geen aard water (DWA/RWA/GEM)")

        # Waarschuwingen
        buis = safe_float(zoek_kolom(rec, "buis_m"))
        if buis == 0:
            waarschuwingen.append(f"  ⚠️  {adres} ({zoek_kolom(rec, 'aard')}): Meters buis = 0")
        if buis > 25:
            waarschuwingen.append(f"  ⚠️  {adres} ({zoek_kolom(rec, 'aard')}): Meters buis = {buis}m (ongewoon lang)")

        bochten = safe_int(zoek_kolom(rec, "bocht"))
        if bochten > 5:
            waarschuwingen.append(f"  ⚠️  {adres} ({zoek_kolom(rec, 'aard')}): {bochten} bochten (veel, check?)")

        if not zoek_kolom(rec, "put_stroomaf"):
            waarschuwingen.append(f"  ⚠️  {adres}: Geen put stroomafwaarts ingevuld")

    # Check DWA/RWA paren
    adressen = {}
    for rec in records:
        soort = zoek_kolom(rec, "soort").upper()
        if soort in ("HA", "WA", ""):
            key = f"{zoek_kolom(rec, 'straat')}_{zoek_kolom(rec, 'huisnr')}"
            aard = zoek_kolom(rec, "aard").upper()
            if key not in adressen:
                adressen[key] = set()
            adressen[key].add(aard)

    for adres, aarden in adressen.items():
        if "DWA" in aarden and "RWA" not in aarden:
            waarschuwingen.append(f"  ⚠️  {adres.replace('_', ' ')}: Heeft DWA maar geen RWA rij")
        if "RWA" in aarden and "DWA" not in aarden:
            waarschuwingen.append(f"  ⚠️  {adres.replace('_', ' ')}: Heeft RWA maar geen DWA rij")

    if fouten:
        print(f"\n{'='*60}")
        print(f"FOUTEN ({len(fouten)}) — moeten opgelost worden:")
        print("="*60)
        for f in fouten:
            print(f)

    if waarschuwingen:
        print(f"\n{'='*60}")
        print(f"WAARSCHUWINGEN ({len(waarschuwingen)}) — controleer:")
        print("="*60)
        for w in waarschuwingen:
            print(w)

    return len(fouten)


# =============================================================================
# RAPPORTAGE
# =============================================================================

def print_samenvatting(records, gps_data):
    """Print een overzicht van de data."""
    ha = [r for r in records if zoek_kolom(r, "soort").upper() in ("HA", "")]
    wa = [r for r in records if zoek_kolom(r, "soort").upper() == "WA"]
    kolk = [r for r in records if zoek_kolom(r, "soort").upper() == "KOLK"]

    dwa = [r for r in records if zoek_kolom(r, "aard").upper() == "DWA"]
    rwa = [r for r in records if zoek_kolom(r, "aard").upper() == "RWA"]

    totaal_buis = sum(safe_float(zoek_kolom(r, "buis_m")) for r in records)
    totaal_bochten = sum(safe_int(zoek_kolom(r, "bocht")) for r in records)
    totaal_stops = sum(safe_int(zoek_kolom(r, "stop")) for r in records)
    totaal_reducties = sum(safe_int(zoek_kolom(r, "reductie")) for r in records)

    matched_gps = sum(1 for r in records if str(zoek_kolom(r, "equipmentnr")) in gps_data)

    print(f"\n{'='*60}")
    print("SAMENVATTING")
    print("="*60)
    print(f"  Totaal rijen:           {len(records)}")
    print(f"  Huisaansluitingen (HA): {len(ha)} rijen")
    print(f"  Wachtaansluitingen (WA):{len(wa)} rijen")
    print(f"  Kolken:                 {len(kolk)} rijen")
    print(f"  DWA rijen:              {len(dwa)}")
    print(f"  RWA rijen:              {len(rwa)}")
    print(f"  GPS-punten gekoppeld:   {matched_gps}/{len(records)}")
    print(f"  ---")
    print(f"  Totaal meters buis:     {totaal_buis:.2f} m")
    print(f"  Totaal bochten:         {totaal_bochten} st")
    print(f"  Totaal stops:           {totaal_stops} st")
    print(f"  Totaal reducties:       {totaal_reducties} st")
    print(f"{'='*60}")


# =============================================================================
# HOOFDPROGRAMMA
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="VLARIO Huisaansluitfiches — Automatische Template Vuller (Colas Belgium)"
    )
    parser.add_argument(
        "--werfdata", required=True,
        help="Pad naar werfdata bestand (Google Sheets export als .xlsx of .csv)"
    )
    parser.add_argument(
        "--gps", default=None,
        help="Pad naar Topcon GPS export (.csv) — optioneel"
    )
    parser.add_argument(
        "--template", required=True,
        help="Pad naar VLARIO .xlsm template bestand"
    )
    parser.add_argument(
        "--output", required=True,
        help="Pad voor output bestand (.xlsm)"
    )
    parser.add_argument(
        "--werf", default=None, choices=["Puurs", "Zwijndrecht"],
        help="Filter op werf (optioneel)"
    )
    parser.add_argument(
        "--fase", default=None,
        help="Filter op fase (optioneel, bv. '1' of 'Burchtsestraat')"
    )
    parser.add_argument(
        "--project-info", default=None,
        help="JSON bestand met projectgegevens (optioneel, anders defaults)"
    )

    args = parser.parse_args()

    print("=" * 60)
    print("VLARIO HUISAANSLUITFICHES — AUTOMATISCHE VULLING")
    print(f"Colas Belgium | {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    print("=" * 60)

    # 1. Lees werfdata
    print(f"\n[1/5] Werfdata inlezen: {args.werfdata}")
    records = lees_werfdata(args.werfdata)
    print(f"  → {len(records)} rijen ingelezen")

    if not records:
        print("[FOUT] Geen data gevonden!")
        sys.exit(1)

    # 2. Filter op werf/fase indien opgegeven
    if args.werf:
        records = [r for r in records if zoek_kolom(r, "werf").lower() == args.werf.lower()]
        print(f"  → Gefilterd op werf '{args.werf}': {len(records)} rijen")

    if args.fase:
        records = [r for r in records
                   if str(zoek_kolom(r, "fase")).lower().find(args.fase.lower()) >= 0]
        print(f"  → Gefilterd op fase '{args.fase}': {len(records)} rijen")

    # 3. Lees GPS data
    gps_data = {}
    if args.gps:
        print(f"\n[2/5] GPS data inlezen: {args.gps}")
        gps_data = lees_gps_csv(args.gps)
    else:
        print(f"\n[2/5] Geen GPS bestand opgegeven — coördinaten overslaan")

    # 4. Valideer
    print(f"\n[3/5] Data valideren...")
    n_fouten = valideer_data(records)
    if n_fouten > 0:
        print(f"\n  ⚠️  {n_fouten} blokkerende fouten gevonden!")
        antwoord = input("  Doorgaan ondanks fouten? (j/n): ").strip().lower()
        if antwoord != "j":
            print("  Afgebroken.")
            sys.exit(1)

    # 5. Samenvatting
    print_samenvatting(records, gps_data)

    # 6. Template vullen
    print(f"\n[4/5] VLARIO template vullen: {args.template}")
    wb = openpyxl.load_workbook(args.template, keep_vba=True)

    # Projectgegevens bepalen
    werf_naam = args.werf or "Puurs"
    project_info = PROJECT_DEFAULTS.get(werf_naam, PROJECT_DEFAULTS["Puurs"])

    # Projectinfo uit JSON laden indien opgegeven
    if args.project_info:
        import json
        with open(args.project_info, "r") as f:
            custom_info = json.load(f)
        project_info.update(custom_info)

    # Tabbladen vullen
    print(f"  Tabblad 'Algemene gegevens'...")
    vul_algemene_gegevens(wb["Algemene gegevens"], project_info)

    print(f"  Tabblad 'Project HA'...")
    n_ha = vul_project_ha(wb["Project HA"], records, gps_data)

    print(f"  Tabblad 'Project WA'...")
    n_wa = vul_project_wa(wb["Project WA"], records, gps_data)

    print(f"  Tabblad 'Project kolk'...")
    n_kolk = vul_project_kolk(wb["Project kolk"], records)

    # 7. Opslaan
    print(f"\n[5/5] Opslaan als: {args.output}")
    wb.save(args.output)
    print(f"  ✅ Klaar! Template opgeslagen.")

    print(f"\n{'='*60}")
    print("VOLGENDE STAPPEN:")
    print("="*60)
    print("  1. Open het bestand in Excel (macro's inschakelen)")
    print("  2. Controleer tabblad 'Algemene gegevens' — vul ontbrekende velden aan")
    print("  3. Controleer de overzichtslijsten (Project HA/WA/kolk)")
    print("  4. Druk op de macro-knop per tabblad om fiches aan te maken")
    print("  5. Vul per fiche de gele velden aan (ligging, putten, situatieschets)")
    print("  6. Voeg foto's in per fiche (4 per DWA + 4 per RWA)")
    print("  7. Druk op 'Print naar PDF' macro voor PDF-export")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
