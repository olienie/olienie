import { useState, useRef, useCallback } from "react";

const FASEN = {
  Zwijndrecht: ["Fase 1 – Bareelstraat","Fase 2 – Burchtsestraat","Fase 3 – Laarstraat-Molenbergstraat","Fase 4 – Vervolg Burchtsestraat","Fase 5 – Alfred van Oststraat","Fase 6 – Laarstraat-Antwerpsesteenweg","Fase 7 – Burchtsestraat-Verbrandendijk"],
  Puurs: ["Fase 1","Fase 2","Fase 3","Pompstation A","Pompstation B"]
};

const SECTIES = ["Project","Putten & GPS","Afstanden","Dieptes & Helling","As-Built Controle","Foto's & Rapport"];

const EMPTY_PUT = (nr="") => ({nr, x:"", y:"", z_taw:"", deksel_hoogte:"", invert_in:"", invert_uit:"", type:"inspectieput", diameter:"400", opmerking:""});

const EMPTY = {
  project:"Zwijndrecht", fase:"", datum: new Date().toISOString().slice(0,10),
  uitvoerder:"", rol:"landmeter", instrument:"Topcon Hyper",
  // Putten (dynamisch)
  putten: [EMPTY_PUT("P01"), EMPTY_PUT("P02")],
  // HA-punten per put
  ha_punten: [],
  // Afstanden
  afst_put_put:"", afst_ha_gevel:"", afst_ha_rooilijn:"",
  afst_ha_put_afwaarts:"", afst_ha_put_opwaarts:"",
  // Dieptes & helling
  diepte_min:"", diepte_max:"", helling_gemeten:"", helling_vereist:"0.30",
  helling_ok:"", lengte_gemeten:"",
  // As-built
  as_built_ok:"", rooilijn_vrij:"", kabels_vrij:"", sewer_verbonden:"",
  opmerkingen_asblt:"",
  // Fotos
  fotos:[null,null,null,null,null,null],
  fotoLabels:["Put stroomafwaarts – voor","Put stroomopwaarts – voor","Aanleg riool bovenaanzicht","Aanleg riool zijaanzicht","HA-putje locatie","Opmeting / sketchbook"],
  opmerkingen:""
};

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const calcHelling = (z1, z2, L) => {
  if (!z1||!z2||!L) return null;
  return (((parseFloat(z1)-parseFloat(z2))/parseFloat(L))*100).toFixed(3);
};

const calcVoortgang = (d) => {
  const req = ["fase","uitvoerder","afst_ha_gevel","afst_ha_rooilijn","diepte_min","helling_gemeten"];
  const allPutCoords = d.putten.every(p=>p.x&&p.y&&p.z_taw);
  const filled = req.filter(k=>d[k]&&String(d[k]).trim()).length;
  return Math.round(((filled/req.length)*0.6 + (allPutCoords?0.3:0) + (d.fotos.filter(Boolean).length/6*0.1))*100);
};

// ─── UI COMPONENTS ───────────────────────────────────────────────────────────
const Label = ({children,req,sub}) => (
  <div style={{marginBottom:4}}>
    <label style={{display:"block",fontSize:11,fontWeight:700,letterSpacing:1,textTransform:"uppercase",color:"#4a5568"}}>
      {children}{req&&<span style={{color:"#e53e3e",marginLeft:2}}>*</span>}
    </label>
    {sub&&<div style={{fontSize:10,color:"#a0aec0",marginTop:1}}>{sub}</div>}
  </div>
);

const Input = ({label,req,sub,value,onChange,type="text",placeholder,unit,hint,readOnly,mono}) => (
  <div style={{marginBottom:14}}>
    {label&&<Label req={req} sub={sub}>{label}</Label>}
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <input type={type} value={value||""} onChange={e=>onChange(e.target.value)}
        placeholder={placeholder||""} readOnly={readOnly}
        style={{flex:1,padding:"10px 12px",border:"1.5px solid #e2e8f0",borderRadius:6,fontSize:14,
          background:readOnly?"#f0fff4":"white",color:"#1a202c",outline:"none",
          fontFamily:mono?"'Courier New',monospace":"inherit",WebkitAppearance:"none"}}/>
      {unit&&<span style={{fontSize:12,color:"#718096",minWidth:28,flexShrink:0}}>{unit}</span>}
    </div>
    {hint&&<div style={{fontSize:11,color:"#a0aec0",marginTop:2}}>{hint}</div>}
  </div>
);

const Select = ({label,req,value,onChange,options,hint}) => (
  <div style={{marginBottom:14}}>
    {label&&<Label req={req}>{label}</Label>}
    <select value={value||""} onChange={e=>onChange(e.target.value)}
      style={{width:"100%",padding:"10px 12px",border:"1.5px solid #e2e8f0",borderRadius:6,
        fontSize:14,background:"white",color:"#1a202c",outline:"none",fontFamily:"inherit",
        WebkitAppearance:"none",backgroundImage:"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23718096' d='M6 8L1 3h10z'/%3E%3C/svg%3E\")",
        backgroundRepeat:"no-repeat",backgroundPosition:"right 12px center",paddingRight:32}}>
      {options.map(o=>typeof o==="string"?<option key={o} value={o}>{o}</option>:<option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
    {hint&&<div style={{fontSize:11,color:"#a0aec0",marginTop:2}}>{hint}</div>}
  </div>
);

const Row2 = ({children}) => <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>{children}</div>;
const Row3 = ({children}) => <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>{children}</div>;

const SecTitle = ({icon,title,sub,color="#1a202c"}) => (
  <div style={{marginBottom:18,paddingBottom:10,borderBottom:"2px solid #e2e8f0"}}>
    <div style={{display:"flex",alignItems:"center",gap:10}}>
      <span style={{fontSize:24}}>{icon}</span>
      <div>
        <div style={{fontSize:17,fontWeight:800,color,letterSpacing:"-0.3px"}}>{title}</div>
        {sub&&<div style={{fontSize:12,color:"#718096",marginTop:1}}>{sub}</div>}
      </div>
    </div>
  </div>
);

const CheckItem = ({label,value,onChange,hint}) => (
  <div style={{display:"flex",alignItems:"flex-start",gap:12,padding:"10px 0",borderBottom:"1px solid #f7fafc"}}>
    <div style={{display:"flex",gap:6,flexShrink:0,marginTop:2}}>
      {["ok","nok","n/a"].map(v=>(
        <button key={v} onClick={()=>onChange(v)}
          style={{padding:"4px 10px",border:"1.5px solid",borderRadius:6,fontSize:11,fontWeight:700,cursor:"pointer",
            borderColor:value===v?(v==="ok"?"#1a7a45":v==="nok"?"#e53e3e":"#c47a00"):"#e2e8f0",
            background:value===v?(v==="ok"?"#1a7a45":v==="nok"?"#e53e3e":"#c47a00"):"white",
            color:value===v?"white":"#718096"}}>
          {v==="ok"?"✓ OK":v==="nok"?"✗ NOK":"—"}
        </button>
      ))}
    </div>
    <div>
      <div style={{fontSize:13,fontWeight:600,color:"#2d3748"}}>{label}</div>
      {hint&&<div style={{fontSize:11,color:"#a0aec0",marginTop:2}}>{hint}</div>}
    </div>
  </div>
);

const FotoSlot = ({index,foto,label,onChange}) => {
  const ref = useRef();
  const handle = (file) => {
    if (!file) return;
    const r = new FileReader();
    r.onload = e => onChange(index, e.target.result);
    r.readAsDataURL(file);
  };
  return (
    <div style={{border:"2px dashed #cbd5e0",borderRadius:8,overflow:"hidden",background:"#f7fafc",cursor:"pointer"}}
      onClick={()=>!foto&&ref.current.click()}
      onDragOver={e=>{e.preventDefault();e.currentTarget.style.borderColor="#3182ce"}}
      onDragLeave={e=>{e.currentTarget.style.borderColor="#cbd5e0"}}
      onDrop={e=>{e.preventDefault();handle(e.dataTransfer.files[0])}}>
      {foto ? (
        <div style={{position:"relative"}}>
          <img src={foto} alt={label} style={{width:"100%",height:130,objectFit:"cover",display:"block"}}/>
          <button onClick={e=>{e.stopPropagation();onChange(index,null)}}
            style={{position:"absolute",top:5,right:5,background:"rgba(0,0,0,0.7)",color:"white",border:"none",borderRadius:20,width:26,height:26,cursor:"pointer",fontSize:15,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
          <div style={{background:"rgba(0,0,0,0.6)",color:"white",padding:"5px 8px",fontSize:10,fontWeight:700,letterSpacing:0.5}}>✓ {label}</div>
        </div>
      ) : (
        <div style={{padding:16,textAlign:"center"}}>
          <div style={{fontSize:24,marginBottom:6}}>📷</div>
          <div style={{fontSize:11,fontWeight:700,color:"#4a5568",lineHeight:1.3}}>{label}</div>
        </div>
      )}
      <input ref={ref} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>handle(e.target.files[0])}/>
    </div>
  );
};

// ─── PUT KAART ───────────────────────────────────────────────────────────────
const PutCard = ({put, idx, onChange, onRemove, canRemove}) => {
  const upd = (k,v) => onChange(idx, {...put, [k]:v});
  return (
    <div style={{background:"white",border:"1.5px solid #e2e8f0",borderRadius:10,overflow:"hidden",marginBottom:12}}>
      <div style={{background:"#2b6cb0",color:"white",padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:18}}>🔵</span>
          <input value={put.nr} onChange={e=>upd("nr",e.target.value)}
            placeholder="Putnummer (bv. P12)"
            style={{background:"transparent",border:"none",color:"white",fontWeight:800,fontSize:15,outline:"none",fontFamily:"inherit",width:180}}/>
        </div>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          <Select value={put.diameter} onChange={v=>upd("diameter",v)}
            options={[{v:"400",l:"Ø400"},{v:"600",l:"Ø600"},{v:"800",l:"Ø800"},{v:"1000",l:"Ø1000"}]}/>
          {canRemove&&<button onClick={()=>onRemove(idx)}
            style={{background:"rgba(255,255,255,.2)",border:"none",color:"white",borderRadius:6,width:28,height:28,cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>}
        </div>
      </div>
      <div style={{padding:"14px 14px 2px"}}>
        <Row3>
          <Input label="X Lambert72" req value={put.x} onChange={v=>upd("x",v)} placeholder="152345.234" mono hint="6 decimalen"/>
          <Input label="Y Lambert72" req value={put.y} onChange={v=>upd("y",v)} placeholder="203456.789" mono hint="6 decimalen"/>
          <Input label="Z TAW" req value={put.z_taw} onChange={v=>upd("z_taw",v)} placeholder="5.23" unit="m" hint="hoogte deksel"/>
        </Row3>
        <Row3>
          <Input label="Dekhoogte" value={put.deksel_hoogte} onChange={v=>upd("deksel_hoogte",v)} placeholder="5.23" unit="m" hint="maaiveld t.o.v. TAW"/>
          <Input label="Invert IN" value={put.invert_in} onChange={v=>upd("invert_in",v)} placeholder="3.48" unit="m TAW" hint="onderkant inkomende buis"/>
          <Input label="Invert UIT" value={put.invert_uit} onChange={v=>upd("invert_uit",v)} placeholder="3.45" unit="m TAW" hint="onderkant uitgaande buis"/>
        </Row3>
        <Input label="Opmerking" value={put.opmerking} onChange={v=>upd("opmerking",v)} placeholder="facultatief"/>
      </div>
    </div>
  );
};

// ─── HA PUNT KAART ───────────────────────────────────────────────────────────
const HAPuntCard = ({ha, idx, onChange, onRemove}) => {
  const upd = (k,v) => onChange(idx, {...ha, [k]:v});
  return (
    <div style={{background:"white",border:"1.5px solid #e2e8f0",borderRadius:10,overflow:"hidden",marginBottom:10}}>
      <div style={{background:"#1a5c35",color:"white",padding:"8px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span>🏠</span>
          <input value={ha.adres||""} onChange={e=>upd("adres",e.target.value)}
            placeholder="Adres (bv. Bareelstraat 12)"
            style={{background:"transparent",border:"none",color:"white",fontWeight:700,fontSize:13,outline:"none",fontFamily:"inherit",width:200}}/>
        </div>
        <button onClick={()=>onRemove(idx)}
          style={{background:"rgba(255,255,255,.2)",border:"none",color:"white",borderRadius:6,width:26,height:26,cursor:"pointer",fontSize:15,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
      </div>
      <div style={{padding:"12px 14px 2px"}}>
        <Row3>
          <Input label="X Lambert72" value={ha.x} onChange={v=>upd("x",v)} placeholder="152345.234" mono/>
          <Input label="Y Lambert72" value={ha.y} onChange={v=>upd("y",v)} placeholder="203456.789" mono/>
          <Input label="Z TAW" value={ha.z_taw} onChange={v=>upd("z_taw",v)} placeholder="4.85" unit="m"/>
        </Row3>
        <Row2>
          <Input label="Afstand gevel rechts" value={ha.afst_gevel} onChange={v=>upd("afst_gevel",v)} unit="m" hint="HA-putje tot gevel"/>
          <Input label="Afstand rooilijn" value={ha.afst_rooilijn} onChange={v=>upd("afst_rooilijn",v)} unit="m"/>
        </Row2>
        <Row2>
          <Input label="Afstand put stroomaf" value={ha.afst_put_af} onChange={v=>upd("afst_put_af",v)} unit="m"/>
          <Input label="Afstand put stroomop" value={ha.afst_put_op} onChange={v=>upd("afst_put_op",v)} unit="m"/>
        </Row2>
      </div>
    </div>
  );
};

// ─── EXPORT ──────────────────────────────────────────────────────────────────
const buildExport = (d) => {
  const lines = [
    `GPS MEETRAPPORT — LANDMETER/PROJECTLEIDER`,
    `Project: ${d.project} | Fase: ${d.fase} | Datum: ${d.datum}`,
    `Uitvoerder: ${d.uitvoerder} | Instrument: ${d.instrument}`,``,
    `=== PUTTEN (Lambert72 / TAW) ===`,
    ...d.putten.map(p=>[
      `Put: ${p.nr} | Ø${p.diameter}mm`,
      `  X: ${p.x||"—"}  Y: ${p.y||"—"}  Z(TAW): ${p.z_taw||"—"}`,
      `  Deksel: ${p.deksel_hoogte||"—"}m  Invert IN: ${p.invert_in||"—"}m  Invert UIT: ${p.invert_uit||"—"}m`,
      p.opmerking?`  Opmerking: ${p.opmerking}`:""
    ].filter(Boolean).join("\n")),``,
    `=== HA-PUNTEN ===`,
    ...(d.ha_punten.length?d.ha_punten.map(h=>[
      `HA: ${h.adres}`,
      `  X: ${h.x||"—"}  Y: ${h.y||"—"}  Z(TAW): ${h.z_taw||"—"}`,
      `  Afstand gevel: ${h.afst_gevel||"—"}m  Rooilijn: ${h.afst_rooilijn||"—"}m`,
      `  Afstand put stroomaf: ${h.afst_put_af||"—"}m  stroomop: ${h.afst_put_op||"—"}m`,
    ].join("\n")):["  (geen HA-punten opgemeten)"]),``,
    `=== ALGEMENE AFSTANDEN ===`,
    `Put-tot-put afstand: ${d.afst_put_put||"—"} m`,
    `HA-putje tot gevel rechts: ${d.afst_ha_gevel||"—"} m`,
    `HA-putje tot rooilijn: ${d.afst_ha_rooilijn||"—"} m`,``,
    `=== DIEPTES & HELLING ===`,
    `Diepte min: ${d.diepte_min||"—"} m  |  Diepte max: ${d.diepte_max||"—"} m`,
    `Helling gemeten: ${d.helling_gemeten||"—"} %  |  Vereist: min. ${d.helling_vereist} %`,
    `Helling OK: ${d.helling_ok||"—"}`,
    `Lengte gemeten: ${d.lengte_gemeten||"—"} lm`,``,
    `=== AS-BUILT CONTROLE ===`,
    `As-built conform plan: ${d.as_built_ok||"—"}`,
    `Rooilijn vrij: ${d.rooilijn_vrij||"—"}`,
    `Kabels/leidingen vrij: ${d.kabels_vrij||"—"}`,
    `Riool correct verbonden: ${d.sewer_verbonden||"—"}`,
    `Opmerkingen: ${d.opmerkingen_asblt||"—"}`,``,
    `Foto's aanwezig: ${d.fotos.filter(Boolean).length}/6`,
    ``,`Algemene opmerkingen: ${d.opmerkingen||"—"}`
  ];
  return lines.join("\n");
};

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function LandmeterApp() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({...EMPTY, putten:[EMPTY_PUT("P01"),EMPTY_PUT("P02")]});
  const [saved, setSaved] = useState([]);
  const [showExport, setShowExport] = useState(false);

  const upd = useCallback((k,v) => setData(d=>({...d,[k]:v})),[]);
  const updPut = useCallback((idx,put) => setData(d=>{const p=[...d.putten];p[idx]=put;return{...d,putten:p}}),[]);
  const addPut = () => setData(d=>({...d,putten:[...d.putten,EMPTY_PUT(`P0${d.putten.length+1}`)]}));
  const remPut = (idx) => setData(d=>({...d,putten:d.putten.filter((_,i)=>i!==idx)}));
  const updHA = useCallback((idx,ha) => setData(d=>{const h=[...d.ha_punten];h[idx]=ha;return{...d,ha_punten:h}}),[]);
  const addHA = () => setData(d=>({...d,ha_punten:[...d.ha_punten,{adres:"",x:"",y:"",z_taw:"",afst_gevel:"",afst_rooilijn:"",afst_put_af:"",afst_put_op:""}]}));
  const remHA = (idx) => setData(d=>({...d,ha_punten:d.ha_punten.filter((_,i)=>i!==idx)}));
  const updFoto = useCallback((i,v)=>setData(d=>{const f=[...d.fotos];f[i]=v;return{...d,fotos:f}}),[]);

  const pct = calcVoortgang(data);
  const hellingCalc = data.putten.length>=2
    ? calcHelling(data.putten[0].invert_uit, data.putten[data.putten.length-1].invert_in, data.afst_put_put)
    : null;

  const downloadTxt = () => {
    const txt = buildExport(data);
    const blob = new Blob([txt],{type:"text/plain;charset=utf-8"});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `GPS_${data.project}_${data.fase?.replace(/[^a-zA-Z0-9]/g,"_")}_${data.datum}.txt`;
    a.click();
  };

  const steps = [

    // 0 — PROJECT
    <div key="proj">
      <SecTitle icon="📋" title="Projectidentificatie" sub="Landmeter / Projectleider formulier" color="#1a202c"/>
      <Row2>
        <Select label="Project" req value={data.project} onChange={v=>{upd("project",v);upd("fase","")}} options={["Zwijndrecht","Puurs"]}/>
        <Select label="Fase" req value={data.fase} onChange={v=>upd("fase",v)} options={["Kies fase...", ...(FASEN[data.project]||[])]}/>
      </Row2>
      <Row2>
        <Input label="Datum opmeting" req type="date" value={data.datum} onChange={v=>upd("datum",v)}/>
        <Select label="Rol uitvoerder" value={data.rol} onChange={v=>upd("rol",v)}
          options={["landmeter","projectleider","werfleider"]}/>
      </Row2>
      <Row2>
        <Input label="Naam uitvoerder" req value={data.uitvoerder} onChange={v=>upd("uitvoerder",v)} placeholder="Naam"/>
        <Select label="Meetinstrument" value={data.instrument} onChange={v=>upd("instrument",v)}
          options={["Topcon Hyper GPS","Leica TS","Trimble R10","Ander GPS-toestel"]}/>
      </Row2>
      <div style={{background:"#ebf8ff",border:"1px solid #bee3f8",borderRadius:8,padding:14,fontSize:12,color:"#2c5282",marginTop:8}}>
        <strong>📌 Werkwijze:</strong> Meet eerst alle putten op (stap 2), dan de HA-punten en afstanden (stap 3), dan de dieptes en helling (stap 4), dan de as-built controle (stap 5). Foto's op stap 6.
      </div>
    </div>,

    // 1 — PUTTEN & GPS
    <div key="putten">
      <SecTitle icon="🔵" title="Putten & GPS-coördinaten" sub="Lambert72 + TAW per inspectieput" color="#2b6cb0"/>
      <div style={{background:"#ebf8ff",border:"1px solid #bee3f8",borderRadius:8,padding:10,marginBottom:16,fontSize:12,color:"#2c5282"}}>
        <strong>Lambert72:</strong> 6 decimalen verplicht voor Vlario-upload. TAW = hoogte t.o.v. zeeniveau. Invert = onderkant buis in de put.
      </div>
      {data.putten.map((put,i)=>(
        <PutCard key={i} put={put} idx={i} onChange={updPut} onRemove={remPut} canRemove={data.putten.length>1}/>
      ))}
      <button onClick={addPut}
        style={{width:"100%",padding:"12px",border:"2px dashed #bee3f8",borderRadius:10,background:"#ebf8ff",
          color:"#2b6cb0",fontWeight:700,fontSize:14,cursor:"pointer",marginBottom:20}}>
        + Inspectieput toevoegen
      </button>

      <SecTitle icon="🏠" title="HA-Punten opmeten" sub="Coördinaten per huisaansluiting (optioneel maar aanbevolen)"/>
      {data.ha_punten.map((ha,i)=>(
        <HAPuntCard key={i} ha={ha} idx={i} onChange={updHA} onRemove={remHA}/>
      ))}
      <button onClick={addHA}
        style={{width:"100%",padding:"12px",border:"2px dashed #c6f6d5",borderRadius:10,background:"#f0fff4",
          color:"#1a7a45",fontWeight:700,fontSize:14,cursor:"pointer"}}>
        + HA-punt toevoegen
      </button>
    </div>,

    // 2 — AFSTANDEN
    <div key="afst">
      <SecTitle icon="📏" title="Afstanden" sub="GPS meetstok of ingevoerd door landmeter / werfleider" color="#553c9a"/>
      <div style={{fontWeight:800,fontSize:12,letterSpacing:1,textTransform:"uppercase",color:"#553c9a",marginBottom:10}}>Putten</div>
      <Input label="Put-tot-put afstand (as)" req value={data.afst_put_put} onChange={v=>upd("afst_put_put",v)}
        unit="m" type="number" step="0.01" placeholder="18.50" hint="Hartlijn put stroomaf tot hartlijn put stroomop"/>

      <div style={{fontWeight:800,fontSize:12,letterSpacing:1,textTransform:"uppercase",color:"#553c9a",margin:"16px 0 10px"}}>HA-Putje (algemeen / als niet per HA opgemeten)</div>
      <Row2>
        <Input label="Afstand HA-putje — rechter gevel" req value={data.afst_ha_gevel} onChange={v=>upd("afst_ha_gevel",v)}
          unit="m" type="number" step="0.01" placeholder="1.20" hint="Van buitenkant HA-putje tot gevel rechts"/>
        <Input label="Afstand HA-putje — rooilijn" req value={data.afst_ha_rooilijn} onChange={v=>upd("afst_ha_rooilijn",v)}
          unit="m" type="number" step="0.01" placeholder="0.50" hint="Afstand HA-putje tot perceelsgrens (rooilijn)"/>
      </Row2>
      <Row2>
        <Input label="Afstand HA-putje tot put stroomaf" value={data.afst_ha_put_afwaarts} onChange={v=>upd("afst_ha_put_afwaarts",v)}
          unit="m" type="number" step="0.01" hint="Vlario: kolom G10"/>
        <Input label="Afstand HA-putje tot put stroomop" value={data.afst_ha_put_opwaarts} onChange={v=>upd("afst_ha_put_opwaarts",v)}
          unit="m" type="number" step="0.01" hint="Vlario: kolom I10"/>
      </Row2>
      <div style={{background:"#faf5ff",border:"1px solid #e9d8fd",borderRadius:8,padding:12,fontSize:12,color:"#553c9a",marginTop:8}}>
        <strong>💡 Tip:</strong> Afstanden HA-putje worden ook per aansluiting opgemeten in de werf-app van de ploeg. Dit zijn de algemene maten voor as-built tekening.
      </div>
    </div>,

    // 3 — DIEPTES & HELLING
    <div key="diepte">
      <SecTitle icon="📐" title="Dieptes & Helling" sub="Controlemeting na aanleg" color="#744210"/>
      <div style={{fontWeight:800,fontSize:12,letterSpacing:1,textTransform:"uppercase",color:"#744210",marginBottom:10}}>Dieptes</div>
      <Row3>
        <Input label="Diepte min" req value={data.diepte_min} onChange={v=>upd("diepte_min",v)}
          unit="m" type="number" step="0.01" placeholder="0.80" hint="ondiepste punt"/>
        <Input label="Diepte max" value={data.diepte_max} onChange={v=>upd("diepte_max",v)}
          unit="m" type="number" step="0.01" placeholder="2.10" hint="diepste punt"/>
        <Input label="Lengte gemeten" value={data.lengte_gemeten} onChange={v=>upd("lengte_gemeten",v)}
          unit="lm" type="number" step="0.1" placeholder="18.50"/>
      </Row3>

      <div style={{fontWeight:800,fontSize:12,letterSpacing:1,textTransform:"uppercase",color:"#744210",margin:"16px 0 10px"}}>Helling</div>
      <Row2>
        <Input label="Helling vereist (min)" value={data.helling_vereist} onChange={v=>upd("helling_vereist",v)}
          unit="%" type="number" step="0.01" placeholder="0.30"/>
        <Input label="Helling gemeten" req value={data.helling_gemeten} onChange={v=>upd("helling_gemeten",v)}
          unit="%" type="number" step="0.001" placeholder="0.325"/>
      </Row2>

      {/* Auto-berekening */}
      {hellingCalc && (
        <div style={{background: parseFloat(hellingCalc)>=parseFloat(data.helling_vereist)?"#f0fff4":"#fff5f5",
          border:`1px solid ${parseFloat(hellingCalc)>=parseFloat(data.helling_vereist)?"#9ae6b4":"#fed7d7"}`,
          borderRadius:8,padding:14,marginTop:8}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:1,textTransform:"uppercase",
            color:parseFloat(hellingCalc)>=parseFloat(data.helling_vereist)?"#1a7a45":"#e53e3e",marginBottom:4}}>
            Auto-berekening (invert UIT P01 → invert IN laatste put / put-tot-put afstand)
          </div>
          <div style={{fontFamily:"monospace",fontSize:18,fontWeight:800,
            color:parseFloat(hellingCalc)>=parseFloat(data.helling_vereist)?"#1a7a45":"#e53e3e"}}>
            {hellingCalc} %
            <span style={{fontSize:13,marginLeft:8}}>
              {parseFloat(hellingCalc)>=parseFloat(data.helling_vereist)?"✓ OK":"⚠ ONDER MINIMUM"}
            </span>
          </div>
        </div>
      )}
      <div style={{marginTop:14}}>
        <Label>Helling conform vereiste?</Label>
        <div style={{display:"flex",gap:8,marginTop:6}}>
          {["ok","nok","twijfel"].map(v=>(
            <button key={v} onClick={()=>upd("helling_ok",v)}
              style={{flex:1,padding:"10px",border:"1.5px solid",borderRadius:8,fontWeight:700,fontSize:13,cursor:"pointer",
                borderColor:data.helling_ok===v?(v==="ok"?"#1a7a45":v==="nok"?"#e53e3e":"#c47a00"):"#e2e8f0",
                background:data.helling_ok===v?(v==="ok"?"#1a7a45":v==="nok"?"#e53e3e":"#c47a00"):"white",
                color:data.helling_ok===v?"white":"#718096"}}>
              {v==="ok"?"✓ OK":v==="nok"?"✗ NOK":"? Twijfel"}
            </button>
          ))}
        </div>
      </div>
    </div>,

    // 4 — AS-BUILT CONTROLE
    <div key="asblt">
      <SecTitle icon="✅" title="As-Built Controle" sub="Projectleider: finale check voor oplevering" color="#1a7a45"/>
      <CheckItem label="Ligging conform uitvoeringsplan" value={data.as_built_ok} onChange={v=>upd("as_built_ok",v)}
        hint="Putten en leidingen op correcte positie t.o.v. plan"/>
      <CheckItem label="Rooilijn vrij / geen inname privé-terrein" value={data.rooilijn_vrij} onChange={v=>upd("rooilijn_vrij",v)}
        hint="Werken beperkt tot openbaar domein"/>
      <CheckItem label="Kruisende kabels / leidingen vrij" value={data.kabels_vrij} onChange={v=>upd("kabels_vrij",v)}
        hint="Nutsinfrastructuur niet beschadigd of te dicht"/>
      <CheckItem label="Riool correct verbonden op collector" value={data.sewer_verbonden} onChange={v=>upd("sewer_verbonden",v)}
        hint="DWA op DWA-riool, RWA op RWA-riool (gescheiden stelsel)"/>
      <div style={{marginTop:14}}>
        <Input label="Opmerkingen as-built" value={data.opmerkingen_asblt} onChange={v=>upd("opmerkingen_asblt",v)}
          placeholder="Afwijkingen, maatregelen, opmerkingen voor dossier..."/>
      </div>
      <div style={{background:"#fffbeb",border:"1px solid #f6e05e",borderRadius:8,padding:12,fontSize:12,color:"#744210",marginTop:8}}>
        <strong>📁 Vlario:</strong> Dit overzicht + GPS-coördinaten + foto's vormen het as-built dossier dat nodig is voor definitieve Vlario-registratie.
      </div>
    </div>,

    // 5 — FOTO'S & RAPPORT
    <div key="fotos">
      <SecTitle icon="📷" title="Foto's & Rapport" sub="6 documentiefoto's voor as-built dossier" color="#c05621"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
        {data.fotos.map((f,i)=>(
          <FotoSlot key={i} index={i} foto={f} label={data.fotoLabels[i]} onChange={updFoto}/>
        ))}
      </div>
      <Input label="Algemene opmerkingen" value={data.opmerkingen} onChange={v=>upd("opmerkingen",v)}
        placeholder="Bijzonderheden voor het dossier..."/>

      {/* Samenvatting */}
      <div style={{background:"white",border:"1.5px solid #e2e8f0",borderRadius:10,overflow:"hidden",marginTop:16,marginBottom:16}}>
        <div style={{background:"#1a202c",color:"white",padding:"10px 14px",fontSize:12,fontWeight:800,letterSpacing:1,textTransform:"uppercase"}}>
          Meetrapport samenvatting
        </div>
        <div style={{padding:14}}>
          {[
            ["Project",`${data.project} – ${data.fase||"—"}`],
            ["Datum",data.datum],
            ["Uitvoerder",`${data.uitvoerder||"—"} (${data.rol})`],
            ["Instrument",data.instrument],
            ["Putten opgemeten",`${data.putten.filter(p=>p.x&&p.y).length} / ${data.putten.length}`],
            ["HA-punten opgemeten",`${data.ha_punten.filter(h=>h.x&&h.y).length} / ${data.ha_punten.length}`],
            ["Put-tot-put",data.afst_put_put?`${data.afst_put_put} m`:"—"],
            ["Helling",data.helling_gemeten?`${data.helling_gemeten}% (${data.helling_ok||"?"})`:"—"],
            ["As-built OK",data.as_built_ok||"—"],
            ["Foto's",`${data.fotos.filter(Boolean).length}/6`],
          ].map(([k,v])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid #f7fafc",fontSize:13}}>
              <span style={{color:"#718096"}}>{k}</span>
              <span style={{fontWeight:600}}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        <button onClick={()=>setSaved(s=>[...s,{...data,savedAt:new Date().toISOString()}])}
          style={{width:"100%",padding:15,background:"#1a7a45",color:"white",border:"none",borderRadius:10,fontSize:15,fontWeight:800,cursor:"pointer"}}>
          ✓ Rapport Opslaan
        </button>
        <button onClick={downloadTxt}
          style={{width:"100%",padding:13,background:"#1a202c",color:"white",border:"none",borderRadius:10,fontSize:14,fontWeight:700,cursor:"pointer"}}>
          ⬇ Download GPS Rapport (.txt)
        </button>
      </div>
      {saved.length>0&&(
        <div style={{marginTop:16,background:"#f0fff4",border:"1px solid #9ae6b4",borderRadius:8,padding:12,fontSize:12,color:"#1a7a45",fontWeight:600}}>
          ✓ {saved.length} rapport(en) opgeslagen deze sessie
        </div>
      )}
    </div>
  ];

  return (
    <div style={{maxWidth:520,margin:"0 auto",minHeight:"100vh",background:"#f4f1eb",fontFamily:"'DM Sans',system-ui,sans-serif"}}>

      {/* HEADER */}
      <div style={{background:"#1a202c",color:"white",padding:"14px 18px",position:"sticky",top:0,zIndex:50}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:9,letterSpacing:3,textTransform:"uppercase",color:"#63b3ed",marginBottom:2,fontWeight:700}}>COLAS — GPS & AS-BUILT</div>
            <div style={{fontSize:15,fontWeight:800}}>Landmeter / Projectleider</div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:9,color:"rgba(255,255,255,.4)",letterSpacing:1,marginBottom:2}}>COMPLEET</div>
            <div style={{fontSize:22,fontWeight:800,color: pct>=80?"#68d391":pct>=50?"#fbbf24":"#fc8181"}}>{pct}%</div>
          </div>
        </div>
        <div style={{display:"flex",gap:4,marginTop:10}}>
          {SECTIES.map((s,i)=>(
            <button key={i} onClick={()=>setStep(i)}
              style={{flex:1,height:4,borderRadius:2,border:"none",cursor:"pointer",transition:"background .2s",
                background: i===step?"#63b3ed":i<step?"#68d391":"rgba(255,255,255,.15)"}}/>
          ))}
        </div>
        <div style={{fontSize:11,color:"rgba(255,255,255,.45)",marginTop:5,letterSpacing:0.5}}>
          {step+1}/{SECTIES.length} — {SECTIES[step]}
        </div>
      </div>

      <div style={{padding:"22px 18px 110px"}}>
        {steps[step]}
      </div>

      {/* NAV */}
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:520,
        background:"white",borderTop:"1.5px solid #e2e8f0",padding:"10px 18px",display:"flex",gap:10,zIndex:50}}>
        <button onClick={()=>setStep(s=>s-1)} disabled={step===0}
          style={{flex:1,padding:13,border:"1.5px solid #e2e8f0",borderRadius:10,
            background:step>0?"#1a202c":"#f7fafc",color:step>0?"white":"#a0aec0",
            fontWeight:700,fontSize:14,cursor:step>0?"pointer":"default"}}>
          ← Vorige
        </button>
        {step<SECTIES.length-1 ? (
          <button onClick={()=>setStep(s=>s+1)}
            style={{flex:2,padding:13,border:"none",borderRadius:10,background:"#2b6cb0",
              color:"white",fontWeight:800,fontSize:14,cursor:"pointer"}}>
            Volgende: {SECTIES[step+1]} →
          </button>
        ) : (
          <button onClick={()=>setSaved(s=>[...s,{...data,savedAt:new Date().toISOString()}])}
            style={{flex:2,padding:13,border:"none",borderRadius:10,background:"#1a7a45",
              color:"white",fontWeight:800,fontSize:14,cursor:"pointer"}}>
            ✓ Rapport Opslaan
          </button>
        )}
      </div>
    </div>
  );
}
